# AIstotle

A calm, complete study workspace: Socratic tutoring, materials, summaries, spaced-repetition flashcards, quizzes, daily planning, focus sessions, and progress tracking.

## Architecture

- **Interface:** Next.js App Router, TypeScript, React, Tailwind CSS, editable shadcn-style Radix UI primitives, Lucide icons, Recharts, React Markdown, and KaTeX.
- **Server:** Next.js Node.js route handlers. No API credentials are exposed to the browser.
- **Identity:** Auth.js / NextAuth, bcrypt password hashes, email/password registration and Google OAuth, encrypted JWT sessions, Prisma adapter. The pinned Auth.js version is `5.0.0-beta.32`.
- **Storage:** PostgreSQL in production; a separate SQLite schema and migration history for local development. Account data is a validated, versioned workspace document owned by exactly one user. Optimistic concurrency prevents silent overwrites. Guest data stays in localStorage, with explicit backup and import.
- **AI:** a streaming provider adapter for OpenAI-compatible APIs and Anthropic. Initial transient failures retry up to twice; an interrupted response is retried explicitly by the student. Structured study aids are validated with Zod.
- **Files:** bounded binary uploads; PDF and DOCX extraction in a time- and memory-limited worker. Originals are not stored.

A workspace document contains the profile, materials and summaries, card schedules, quizzes, scored attempts, study tasks, focus sessions, chat messages, and activity dates. The schema is in `src/lib/schema.ts`; the relational identity and ownership schema is in `prisma/schema.prisma`.

This document-storage design keeps each personal workspace update atomic and portable across PostgreSQL and SQLite. It deliberately caps workspace size instead of pretending to offer unlimited storage. Large institutional deployments should move high-volume history into normalized, paginated tables.

## Folder structure

| Path                         | Purpose                                                  |
| ---------------------------- | -------------------------------------------------------- |
| `src/app/`                   | App Router page, layout, errors, global styling          |
| `src/app/api/auth/`          | Auth.js callbacks and registration                       |
| `src/app/api/ai/`            | Streaming chat and structured generation                 |
| `src/app/api/materials/`     | Bounded upload and extraction                            |
| `src/app/api/workspace/`     | Authenticated reads and revision-checked saves           |
| `src/app/api/config/`        | Public capability flags, never credentials               |
| `src/app/api/health/`        | Database readiness probe                                 |
| `src/components/`            | Complete study screens, onboarding, account UI           |
| `src/components/ui/`         | Editable Radix/shadcn-style components                   |
| `src/hooks/`                 | Guest storage, account sync, export, conflict handling   |
| `src/lib/`                   | Validation, SM-2, scoring, planning, security, AI, SSE   |
| `src/auth.ts`                | Auth.js configuration                                    |
| `prisma/`                    | PostgreSQL schema and checked-in migration               |
| `prisma/local/`              | SQLite schema and checked-in migration                   |
| `scripts/`                   | Parser worker, local database setup, deployment helpers  |
| `tests/`                     | 43 unit, route-handler, parser, and authentication tests |
| `Dockerfile`, `compose.yaml` | Node app, PostgreSQL, and migration job                  |
| `.env.example`               | Documented configuration, without secrets                |

## Local setup — SQLite

Use Node.js 22.13 or newer and npm. The project was tested with Node.js 24.

```bash
npm ci
cp .env.example .env
openssl rand -base64 32
```

Put the generated value into `AUTH_SECRET` in `.env`. Keep these local values:

```dotenv
DATABASE_URL="file:./dev.db"
AUTH_URL="http://localhost:3000"
```

Then run:

```bash
npm run db:local
npm run dev
```

Open `http://localhost:3000`. `db:local` creates the SQLite file, applies the checked-in migration, and generates the SQLite Prisma client. Guest tools and email/password accounts work without an AI key. Add the AI credentials below for tutoring and generation.

To check a production-mode build against SQLite:

```bash
npm run build:local
npm start
```

Do not run `npm run build` against a running SQLite preview: that command generates the **PostgreSQL** client. Regenerate the appropriate client whenever switching database providers.

## Environment variables

| Variable                 | Purpose                                                                          |
| ------------------------ | -------------------------------------------------------------------------------- |
| `DATABASE_URL`           | SQLite locally or PostgreSQL in production                                       |
| `MIGRATION_DATABASE_URL` | Optional direct PostgreSQL URL for migrations when the runtime URL uses a pooler |
| `AUTH_SECRET`            | Strong random secret, required for authentication                                |
| `AUTH_URL`               | Exact app origin, including protocol and port; used for same-origin write checks |
| `AUTH_GOOGLE_ID`         | Google OAuth client ID; optional                                                 |
| `AUTH_GOOGLE_SECRET`     | Google OAuth client secret; optional                                             |
| `AI_PROVIDER`            | `openai-compatible` or `anthropic`                                               |
| `AI_BASE_URL`            | Trusted API base URL, including `/v1` where required                             |
| `AI_API_KEY`             | Server-side provider API key                                                     |
| `AI_MODEL`               | A model available to your provider account                                       |
| `ALLOW_GUEST_AI`         | `true` to allow rate-limited guest AI; `false` to require sign-in                |
| `AI_REQUESTS_PER_DAY`    | Per-user or per-guest-IP daily AI request limit, default 100, maximum 1000       |
| `TRUST_PROXY`            | Only enable behind a proxy that overwrites `X-Real-IP`                           |
| `POSTGRES_PASSWORD`      | Docker Compose PostgreSQL password; use a long hex/alphanumeric value            |

Never prefix a secret with `NEXT_PUBLIC_`. Never commit `.env`.

### AI providers

For an OpenAI-compatible API, set `AI_PROVIDER="openai-compatible"`, its trusted `AI_BASE_URL`, your `AI_API_KEY`, and a supported `AI_MODEL`. The example model is configurable, not a requirement.

For Anthropic, set **all** of the following appropriately:

```dotenv
AI_PROVIDER="anthropic"
AI_BASE_URL="https://api.anthropic.com/v1"
AI_API_KEY=""
AI_MODEL=""
```

Fill both empty fields with your account's key and model ID. API endpoints accept only server-configured URLs; users cannot supply arbitrary upstream URLs. HTTPS is required except for localhost development providers.

### Google login

Create a Google OAuth web application. Register the exact redirect URI:

```text
http://localhost:3000/api/auth/callback/google
```

For production, replace the origin with the deployed HTTPS origin and set `AUTH_URL` to that same origin. Add `AUTH_GOOGLE_ID` and `AUTH_GOOGLE_SECRET`, then restart or redeploy. Google is offered in the UI only when both credentials exist.

Google accounts must report a verified email. Automatic email-based account linking is disabled. If an email already has a password account, sign in with that password rather than silently linking an unverified identity.

## PostgreSQL setup

Create an empty PostgreSQL database and set `DATABASE_URL` to its connection string. Use the connection-pooling settings recommended by your database host for serverless environments.

```bash
npm run db:migrate
npm run build
npm start
```

`db:migrate` deploys the PostgreSQL migration. It does not copy data from SQLite. To move study data, export a workspace in Settings, sign in to the destination account, and import the JSON backup. Account credentials are managed separately.

Use a dedicated database for each environment. Never point preview deployments at the production database by accident.

## Vercel deployment

1. Push the extracted project to your own Git repository. Import that repository into Vercel with the Next.js preset and Node.js 22 or newer.
2. Provision PostgreSQL and set the production environment variables from the table. Set `AUTH_URL` to your actual HTTPS app origin. Supply AI and Google credentials for the features you want enabled.
3. Set the build command to `npm run deploy:build`. It applies migrations, generates the PostgreSQL client, and builds the app. If your team runs migrations in a separate release job, use `npm run build` after that job instead.
4. When using a pooler, set `MIGRATION_DATABASE_URL` to a direct connection string suitable for migration jobs. `deploy:build` uses that only for migrations and restores `DATABASE_URL` for the application build.
5. Use separate variables/databases for Preview and Production. Deploy, then verify `/api/health` returns `{"status":"ok"}`.
6. Complete the external-service smoke checks in `VERIFICATION.md`, including Google callback URLs and a live tutor response.

The AI route declares a 120-second maximum duration; the import route declares 30 seconds. Ensure your chosen hosting configuration supports those limits. Uploads are limited to 4 MiB. This is a server application: do not use a static export.

## Docker deployment

Docker and Docker Compose are required. Start with `.env.example`, fill `AUTH_SECRET`, set a long hex/alphanumeric `POSTGRES_PASSWORD`, and keep `AUTH_URL="http://localhost:3000"` for a local container test. Add your AI/Google settings if needed.

```bash
docker compose up --build -d
docker compose ps
```

The database health check runs first, the one-shot migration service applies the schema, and then the app starts on port 3000. PostgreSQL data persists in the named `postgres_data` volume. The app runs as the non-root `node` user.

For a custom container platform, build the `migrate` target for the migration job and the `runner` target for the web service. Inject secrets at runtime. The Docker build never copies `.env` or the development database.

Terminate HTTPS at a trusted gateway for public hosting. Only set `TRUST_PROXY=true` when that gateway strips incoming `X-Real-IP` and writes the real address itself. Vercel uses its trusted forwarding header automatically. Without a trusted client-IP source, anonymous callers share a conservative quota.

## Using the app

1. Pick a subject, starting level, and learning goal.
2. Add a topic, paste notes, or upload a PDF/TXT/DOCX in **My materials**.
3. Generate a summary with key concepts and a glossary, or ask **AI tutor** to guide you.
4. Generate or create **Flashcards**. Reveal the answer, then rate recall as Again, Hard, Good, or Easy.
5. Create a **Quiz**. Multiple choice, true/false, and short-answer questions give immediate explanations. Finish all questions to save the score.
6. Create a **Study plan** from your exam date and daily hours. Check tasks as you finish.
7. Use **Focus timer**. Completed work sessions count toward study time; breaks do not.
8. Review streaks, focus time, accuracy, and weaker topics in **Overview**.

The account and guest workspaces are intentionally separate. Sign in, open Settings, and select **Import guest work** to replace the account workspace with that device's guest data. Export first if both contain work you want to retain. JSON restore has the same explicit replacement behavior.

### Learning rules

- **SM-2:** ease starts at 2.5, with a floor of 1.3. Successful first and second reviews schedule 1 and 6 days. Later reviews multiply the previous interval by the previous ease. Failed recall resets repetitions and schedules one day. Buttons map to qualities 1, 3, 4, and 5.
- **Short answers:** case, whitespace, Unicode normalization, and trailing sentence punctuation are normalized. The response must match the answer or an explicitly accepted alternative. This is recall practice, not semantic essay grading.
- **Plan:** rotates the available materials, reserves approximately one quarter of the time for recall, and prioritizes practice on the last two days. Days run from today through the day before the exam. This schedule is deterministic and works without AI.
- **Focus:** countdowns use a saved deadline rather than decrementing a counter blindly. Pausing preserves remaining time. Completed sessions are deduplicated by ID; after four work sessions, the suggested break is 15 minutes.
- **Progress:** quiz accuracy is weighted by answered question count. Weak topics have accuracy below 70%. Streaks use the student's browser-local calendar days and remain active if the last study day was yesterday.

## Limits and safeguards

- Uploads: PDF, DOCX, UTF-8 TXT; at most 4 MiB, 60,000 extracted characters, and 100 PDF pages. Scanned PDFs require OCR before upload. DOCX archives are checked for entry count and total uncompressed size.
- Parser workers: 15-second timeout and 128 MiB V8 heap cap. This heap cap is not a whole-process RSS guarantee; hosting memory limits still apply.
- Workspace: under 3.9 MB client-side; 4 MB server request limit. At most 30 materials, 1,000 cards, 100 quizzes, 500 retained attempts, 1,500 plan tasks, 3,000 retained focus sessions, and 300 retained chat messages.
- AI: 10 requests/minute plus the daily limit. Registration: 5/hour per trusted client-IP key. Login: 20 attempts/15 minutes per IP key and 10/15 minutes per email. Uploads: 10/minute per IP key. Limits are persisted in the database, not per-process memory.
- Zod input/output validation, owner-scoped database access, same-origin mutation checks, bounded streamed bodies, hashed passwords, auth CSRF protection, and revision checks.
- Markdown raw HTML is disabled, unsafe URL schemes are filtered, remote Markdown images are not rendered, and KaTeX trust is disabled. The CSP allows inline scripts required by this build and inline styles; it is defense in depth, not a replacement for safe rendering.
- Original documents, credentials, and provider response bodies are not logged by application error handlers.

This is a personal learning application. Quiz scores and study activity are user-editable practice data, not a tamper-proof assessment record. Password reset, email-verification delivery, institution administration, billing, OCR, and multi-user collaboration are outside the requested feature set.

## Tests and maintenance

```bash
npm test
npm run typecheck
npm audit --omit=dev
npm run build:local
npm run verify:bundle
```

After switching to a production PostgreSQL environment, run `npm run build` instead of `build:local`. Use `npm run format` to format the editable source. The lockfile is included for reproducible installs. Dependency overrides pin patched KaTeX and deepmerge-ts releases; keep them under review when upgrading their parent packages.

`VERIFICATION.md` records what was exercised and what still requires your external services. An implementation and successful build cannot by themselves certify a live deployment, complete WCAG AA conformance, or an independent security audit.

## Reference documentation

- [Next.js deployment](https://nextjs.org/docs/app/getting-started/deploying)
- [Next.js standalone output](https://nextjs.org/docs/app/api-reference/config/next-config-js/output)
- [Auth.js credentials](https://authjs.dev/getting-started/authentication/credentials)
- [Auth.js Prisma adapter](https://authjs.dev/getting-started/adapters/prisma)
- [Vercel environment variables](https://vercel.com/docs/environment-variables)
