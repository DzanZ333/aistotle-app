import type { NextConfig } from "next";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

// Workers load modules outside Next's static import graph. Trace the complete
// installed dependency closure, including nested npm dependencies and binaries.
function workerDependencies(): string[] {
  const root = process.cwd();
  const visited = new Set<string>();
  function walk(name: string, from: string, optional = false): void {
    const requireFrom = createRequire(from);
    let manifest: string;
    try {
      try {
        manifest = requireFrom.resolve(`${name}/package.json`);
      } catch {
        let directory = path.dirname(requireFrom.resolve(name));
        while (true) {
          const candidate = path.join(directory, "package.json");
          if (
            fs.existsSync(candidate) &&
            JSON.parse(fs.readFileSync(candidate, "utf8")).name === name
          ) {
            manifest = candidate;
            break;
          }
          const parent = path.dirname(directory);
          if (parent === directory)
            throw new Error(`Missing package manifest: ${name}`);
          directory = parent;
        }
      }
    } catch (error) {
      if (optional) return;
      throw error;
    }
    if (visited.has(manifest)) return;
    visited.add(manifest);
    const pkg = JSON.parse(fs.readFileSync(manifest, "utf8"));
    for (const dependency of Object.keys(pkg.dependencies || {}))
      walk(dependency, manifest);
    for (const dependency of Object.keys(pkg.optionalDependencies || {}))
      walk(dependency, manifest, true);
  }
  for (const name of ["pdf-parse", "mammoth", "yauzl"])
    walk(name, path.join(root, "package.json"));
  return [...visited].map(
    (file) =>
      "./" +
      path.relative(root, path.dirname(file)).split(path.sep).join("/") +
      "/**",
  );
}

const config: NextConfig = {
  output: "standalone",
  outputFileTracingIncludes: {
    "/api/materials": ["./scripts/parse-worker.cjs", ...workerDependencies()],
  },
  serverExternalPackages: [
    "pdf-parse",
    "pdfjs-dist",
    "mammoth",
    "yauzl",
    "@napi-rs/canvas",
  ],
  experimental: { cpus: 2 },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
          {
            key: "Content-Security-Policy",
            value:
              "default-src 'self'; script-src 'self' 'unsafe-inline'" +
              (process.env.NODE_ENV === "development" ? " 'unsafe-eval'" : "") +
              "; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self' https://accounts.google.com; object-src 'none'",
          },
        ],
      },
    ];
  },
};
export default config;
