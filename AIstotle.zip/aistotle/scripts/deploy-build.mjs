import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const steps = [
  [
    require.resolve("prisma/build/index.js"),
    ["migrate", "deploy"],
    {
      ...process.env,
      DATABASE_URL:
        process.env.MIGRATION_DATABASE_URL || process.env.DATABASE_URL,
    },
  ],
  [require.resolve("prisma/build/index.js"), ["generate"], process.env],
  [require.resolve("next/dist/bin/next"), ["build", "--webpack"], process.env],
];
for (const [command, args, env] of steps) {
  const result = spawnSync(process.execPath, [command, ...args], {
    stdio: "inherit",
    env,
  });
  if (result.status !== 0) process.exit(result.status || 1);
}
