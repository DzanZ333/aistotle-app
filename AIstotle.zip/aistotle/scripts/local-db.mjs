import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
if (fs.existsSync(".env")) process.loadEnvFile(".env");
const url = process.env.DATABASE_URL || "file:./dev.db";
if (!url.startsWith("file:"))
  throw new Error(
    "db:local requires a SQLite file: DATABASE_URL. Use db:migrate for PostgreSQL.",
  );
const file = path.resolve("prisma/local", url.slice(5).split("?")[0]);
fs.mkdirSync(path.dirname(file), { recursive: true });
fs.closeSync(fs.openSync(file, "a"));
for (const args of [["migrate", "deploy"], ["generate"]]) {
  const result = spawnSync(
    process.execPath,
    [
      require.resolve("prisma/build/index.js"),
      ...args,
      "--schema",
      "prisma/local/schema.prisma",
    ],
    { stdio: "inherit", env: { ...process.env, DATABASE_URL: url } },
  );
  if (result.status !== 0) process.exit(result.status || 1);
}
