const { parentPort, workerData } = require("node:worker_threads");
const buffer = Buffer.from(workerData.bytes);
async function checkZip() {
  const yauzl = require("yauzl");
  await new Promise((resolve, reject) =>
    yauzl.fromBuffer(
      buffer,
      { lazyEntries: true, validateEntrySizes: true },
      (error, zip) => {
        if (error) return reject(error);
        let size = 0,
          count = 0,
          document = false;
        zip.on("error", reject);
        zip.on("entry", (entry) => {
          size += entry.uncompressedSize;
          count++;
          if (size > 20_000_000 || count > 1000) {
            zip.close();
            return reject(
              new Error("The DOCX expands beyond the safe size limit."),
            );
          }
          if (entry.fileName === "word/document.xml") document = true;
          zip.readEntry();
        });
        zip.on("end", () =>
          document
            ? resolve()
            : reject(new Error("This file is not a valid DOCX document.")),
        );
        zip.readEntry();
      },
    ),
  );
}
(async () => {
  let text;
  if (workerData.extension === "pdf") {
    const { PDFParse } = require("pdf-parse");
    const parser = new PDFParse({
      data: new Uint8Array(buffer),
      isEvalSupported: false,
    });
    try {
      const info = await parser.getInfo();
      if (info.total > 100)
        throw new Error("PDF files may contain at most 100 pages.");
      const result = await parser.getText();
      text = result.text;
    } finally {
      await parser.destroy();
    }
  } else {
    await checkZip();
    const mammoth = require("mammoth");
    const result = await mammoth.extractRawText(
      { buffer },
      { externalFileAccess: false },
    );
    text = result.value;
  }
  if (text.length > 60000)
    throw new Error(
      "The extracted document is too long. Upload a section under 60,000 characters.",
    );
  parentPort.postMessage({ text });
})().catch((error) =>
  parentPort.postMessage({
    error: error.message || "Could not read this document.",
  }),
);
