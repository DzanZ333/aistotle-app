import fs from "node:fs";
import path from "node:path";
import { Worker } from "node:worker_threads";
const trace = JSON.parse(
  fs.readFileSync(".next/server/app/api/materials/route.js.nft.json", "utf8"),
).files;
for (const name of [
  "mammoth",
  "yauzl",
  "pend",
  "pdf-parse",
  "pdfjs-dist",
  "jszip",
  "lop",
  "xmlbuilder",
  "underscore",
  "@xmldom/xmldom",
]) {
  if (!trace.some((file) => file.includes(`/node_modules/${name}/`)))
    throw new Error(`Missing deployment dependency: ${name}`);
}
const fixture = fs.readFileSync("tests/fixtures.ts", "utf8");
for (const extension of ["pdf", "docx"]) {
  const match = fixture.match(
    new RegExp(`export const ${extension}Base64\\s*=\\s*["']([^"']+)`),
  );
  if (!match) throw new Error(`Missing ${extension} test fixture`);
  const bytes = new Uint8Array(Buffer.from(match[1], "base64"));
  const text = await new Promise((resolve, reject) => {
    const worker = new Worker(
      path.resolve(".next/standalone/scripts/parse-worker.cjs"),
      { workerData: { bytes, extension } },
    );
    const timer = setTimeout(() => {
      void worker.terminate();
      reject(new Error("Parser smoke test timed out"));
    }, 15000);
    worker.once("message", (result) => {
      clearTimeout(timer);
      void worker.terminate();
      result.error ? reject(new Error(result.error)) : resolve(result.text);
    });
    worker.once("error", (error) => {
      clearTimeout(timer);
      reject(error);
    });
  });
  if (!text.includes("Photosynthesis makes glucose."))
    throw new Error("Unexpected extracted text");
  console.log(`Packaged ${extension.toUpperCase()} worker passed`);
}
