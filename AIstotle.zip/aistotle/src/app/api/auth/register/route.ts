import { z } from "zod";
import { hash } from "bcryptjs";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import {
  checkOrigin,
  clientKey,
  rateLimit,
  readJson,
  errorResponse,
  HttpError,
} from "@/lib/security";
const schema = z.object({
  name: z.string().trim().min(1).max(80),
  email: z
    .email()
    .max(254)
    .transform((v) => v.toLowerCase()),
  password: z
    .string()
    .min(12)
    .max(72)
    .refine((v) => Buffer.byteLength(v, "utf8") <= 72),
});
export async function POST(request: Request) {
  try {
    checkOrigin(request);
    await rateLimit(`register:${clientKey(request)}`, 5, 3600);
    const data = schema.parse(await readJson(request, 4000));
    const passwordHash = await hash(data.password, 12);
    try {
      await db.user.create({
        data: { name: data.name, email: data.email, passwordHash },
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002"
      )
        throw new HttpError(
          409,
          "This address cannot be registered. Try signing in instead.",
        );
      throw error;
    }
    return Response.json({ ok: true }, { status: 201 });
  } catch (error) {
    return errorResponse(error);
  }
}
