export async function GET() {
  return Response.json({
    aiConfigured: Boolean(process.env.AI_API_KEY && process.env.AI_MODEL),
    googleConfigured: Boolean(
      process.env.AUTH_GOOGLE_ID && process.env.AUTH_GOOGLE_SECRET,
    ),
    guestAI: process.env.ALLOW_GUEST_AI === "true",
  });
}
