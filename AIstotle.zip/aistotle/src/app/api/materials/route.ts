import { Worker } from "node:worker_threads";
import path from "node:path";
import {
  checkOrigin,
  clientKey,
  rateLimit,
  readBytes,
  errorResponse,
  HttpError,
} from "@/lib/security";
export const runtime = "nodejs";
export const maxDuration = 30;
export async function POST(request: Request) {
  try {
    checkOrigin(request);
    await rateLimit(`file:${clientKey(request)}`, 10, 60);
    const name = new URL(request.url).searchParams.get("name") || "";
    const extension = name.split(".").pop()?.toLowerCase();
    if (!extension || !["txt", "pdf", "docx"].includes(extension))
      throw new HttpError(415, "Upload a PDF, TXT, or DOCX file.");
    const bytes = await readBytes(request, 4 * 1024 * 1024);
    if (!bytes.length) throw new HttpError(400, "The file is empty.");
    if (
      extension === "pdf" &&
      new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-"
    )
      throw new HttpError(415, "This is not a valid PDF file.");
    if (extension === "docx" && (bytes[0] !== 80 || bytes[1] !== 75))
      throw new HttpError(415, "This is not a valid DOCX file.");
    let text: string;
    if (extension === "txt") {
      try {
        text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
      } catch {
        throw new HttpError(400, "Save the text file as UTF-8 and retry.");
      }
      if (text.includes("\0"))
        throw new HttpError(400, "This file contains binary content.");
    } else
      text = await new Promise<string>((resolve, reject) => {
        const worker = new Worker(
          path.join(process.cwd(), "scripts/parse-worker.cjs"),
          {
            workerData: { bytes, extension },
            resourceLimits: { maxOldGenerationSizeMb: 128, stackSizeMb: 4 },
          },
        );
        let settled = false;
        const finish = (error: Error | null, value?: string) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          void worker.terminate();
          error ? reject(error) : resolve(value || "");
        };
        const timer = setTimeout(
          () =>
            finish(
              new HttpError(
                422,
                "This document took too long to read. Try a smaller section.",
              ),
            ),
          15000,
        );
        worker.once("message", (result) =>
          finish(
            result.error ? new HttpError(422, result.error) : null,
            result.text,
          ),
        );
        worker.once("error", () =>
          finish(
            new HttpError(
              422,
              "Could not read this file. It may be damaged or password-protected.",
            ),
          ),
        );
        worker.once("exit", () => {
          if (!settled)
            finish(
              new HttpError(
                422,
                "Document processing stopped. Try a smaller file.",
              ),
            );
        });
      });
    text = text.replace(/\u0000/g, "").trim();
    if (!text)
      throw new HttpError(
        422,
        "No readable text was found. For scanned PDFs, run OCR first or paste the text.",
      );
    if (text.length > 60000)
      throw new HttpError(
        413,
        "Extracted text exceeds 60,000 characters. Upload a smaller section.",
      );
    return Response.json({
      text,
      title: name.replace(/\.[^.]+$/, "").slice(0, 150),
    });
  } catch (error) {
    return errorResponse(error);
  }
}
