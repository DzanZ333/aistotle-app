import { auth } from "@/auth";
import { db } from "@/lib/db";
import { workspaceSchema, emptyWorkspace } from "@/lib/schema";
import { z } from "zod";
import {
  checkOrigin,
  readJson,
  errorResponse,
  HttpError,
  rateLimit,
} from "@/lib/security";
export async function GET() {
  try {
    const session = await auth();
    if (!session?.user.id) throw new HttpError(401, "Please sign in.");
    const workspace = await db.workspace.upsert({
      where: { userId: session.user.id },
      create: {
        userId: session.user.id,
        data: JSON.stringify(emptyWorkspace()),
      },
      update: {},
    });
    return Response.json(
      { data: JSON.parse(workspace.data), revision: workspace.revision },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
export async function PUT(request: Request) {
  try {
    checkOrigin(request);
    const session = await auth();
    if (!session?.user.id) throw new HttpError(401, "Please sign in.");
    await rateLimit(`save:${session.user.id}`, 120);
    const { data, revision } = z
      .object({ data: workspaceSchema, revision: z.number().int().min(0) })
      .parse(await readJson(request, 4_000_000));
    const result = await db.workspace.updateMany({
      where: { userId: session.user.id, revision },
      data: { data: JSON.stringify(data), revision: { increment: 1 } },
    });
    if (!result.count)
      throw new HttpError(
        409,
        "A newer version exists in another tab. Export your changes, then reload before continuing.",
      );
    return Response.json({ revision: revision + 1 });
  } catch (error) {
    return errorResponse(error);
  }
}
