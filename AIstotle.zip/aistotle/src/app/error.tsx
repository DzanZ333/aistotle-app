"use client";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main className="grid min-h-screen place-items-center p-8">
      <div className="panel max-w-md">
        <h1 className="text-2xl font-bold">Let’s try that again.</h1>
        <p className="my-4">
          This page could not load. Your saved work is still available.
        </p>
        <button
          className="rounded-lg bg-primary px-4 py-2 text-primary-foreground"
          onClick={reset}
        >
          Try again
        </button>
      </div>
    </main>
  );
}
