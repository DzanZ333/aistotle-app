import type { Metadata } from "next";
import { Providers } from "@/components/providers";
import "./globals.css";
import "katex/dist/katex.min.css";
export const metadata: Metadata = {
  title: "AIstotle — A little curiosity, a lot of progress",
  description:
    "Your calm space for deeper understanding. Learn with a Socratic AI tutor, flashcards, quizzes, and a study plan that fits your life.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
