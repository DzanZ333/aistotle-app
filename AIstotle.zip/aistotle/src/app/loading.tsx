export default function Loading() {
  return (
    <main className="grid min-h-screen place-items-center" role="status">
      Opening your study space…
    </main>
  );
}
