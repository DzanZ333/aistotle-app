import Link from "next/link";
export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center p-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold">A question for another path.</h1>
        <p className="my-4">That page does not exist.</p>
        <Link className="underline" href="/">
          Return to AIstotle
        </Link>
      </div>
    </main>
  );
}
