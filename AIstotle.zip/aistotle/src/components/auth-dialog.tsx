"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Field, Notice } from "./ui/shared";
import { api } from "@/lib/utils";
export function AuthDialog({
  open,
  onOpenChange,
  google,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  google: boolean;
}) {
  const [register, setRegister] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email")),
      password = String(form.get("password"));
    try {
      if (register)
        await api("/api/auth/register", {
          method: "POST",
          body: JSON.stringify({
            name: String(form.get("name")),
            email,
            password,
          }),
        });
      const result = await signIn("credentials", {
        email,
        password,
        redirect: false,
      });
      if (result?.error)
        throw new Error(
          "Could not sign in. Check your email and password, or wait a few minutes if you have tried several times.",
        );
      onOpenChange(false);
    } catch (error) {
      setError(error instanceof Error ? error.message : "Could not sign in.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <span className="brand-mark mb-5">
          a<span>✳</span>
        </span>
        <DialogTitle className="text-2xl font-semibold">
          {register ? "Make room for curiosity." : "Welcome back."}
        </DialogTitle>
        <DialogDescription className="mb-6 mt-2 text-sm text-muted-foreground">
          Save your learning across devices. Guest work can be imported after
          signing in.
        </DialogDescription>
        {error && <Notice>{error}</Notice>}
        <form onSubmit={submit} className="grid gap-4">
          {register && (
            <Field label="Your name">
              <input name="name" autoComplete="name" maxLength={80} required />
            </Field>
          )}
          <Field label="Email address">
            <input
              name="email"
              type="email"
              autoComplete="email"
              maxLength={254}
              required
            />
          </Field>
          <Field
            label="Password"
            hint={
              register
                ? "Use at least 12 characters (up to 72 UTF-8 bytes)."
                : undefined
            }
          >
            <input
              name="password"
              type="password"
              autoComplete={register ? "new-password" : "current-password"}
              minLength={register ? 12 : 1}
              maxLength={72}
              required
            />
          </Field>
          <Button type="submit" disabled={busy}>
            {busy ? "One moment…" : register ? "Create account" : "Sign in"}
          </Button>
        </form>
        {google && (
          <Button
            variant="outline"
            className="mt-3 w-full"
            onClick={() => void signIn("google", { callbackUrl: "/" })}
          >
            Continue with Google
          </Button>
        )}
        <div className="mt-5 text-center text-sm">
          <button
            className="text-accent-strong underline underline-offset-4"
            onClick={() => {
              setRegister(!register);
              setError("");
            }}
          >
            {register
              ? "Already have an account? Sign in"
              : "New here? Create an account"}
          </button>
        </div>
        <p className="mt-5 text-xs text-muted-foreground">
          Your materials are sent to the configured AI service only when you
          request AI help.
        </p>
      </DialogContent>
    </Dialog>
  );
}
