"use client";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ArrowUpRight,
  BookOpen,
  Flame,
  Layers,
  MessageCircle,
  Target,
  Timer,
  Plus,
  FileText,
  Sparkles,
  Check,
} from "lucide-react";
import type { StudyStore } from "@/hooks/use-workspace";
import { localDay, studyStreak } from "@/lib/study";
import { Button } from "./ui/button";
import { Empty, Progress } from "./ui/shared";
export type View =
  | "dashboard"
  | "tutor"
  | "materials"
  | "flashcards"
  | "quizzes"
  | "plan"
  | "focus"
  | "settings";
export function Dashboard({
  store,
  navigate,
  addMaterial,
  chooseMaterial,
  name,
}: {
  store: StudyStore;
  navigate: (v: View) => void;
  addMaterial: () => void;
  chooseMaterial: (id: string) => void;
  name?: string | null;
}) {
  const { data } = store;
  const due = data.cards.filter((c) => new Date(c.due) <= new Date()).length;
  const total = data.attempts.reduce((a, x) => a + x.total, 0),
    correct = data.attempts.reduce((a, x) => a + x.correct, 0);
  const minutes = data.focus.reduce((a, x) => a + x.minutes, 0);
  const series = Array.from({ length: 7 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - 6 + index);
    return {
      day: date.toLocaleDateString("en", { weekday: "short" }),
      minutes: data.focus
        .filter((f) => localDay(new Date(f.createdAt)) === localDay(date))
        .reduce((sum, f) => sum + f.minutes, 0),
    };
  });
  const today = data.tasks.filter((t) => t.date === localDay());
  const completed = today.filter((t) => t.done).length;
  const topicMap = new Map<string, { correct: number; total: number }>();
  for (const attempt of data.attempts)
    for (const topic of attempt.topics) {
      const x = topicMap.get(topic.topic) || { correct: 0, total: 0 };
      x.total++;
      x.correct += Number(topic.correct);
      topicMap.set(topic.topic, x);
    }
  const weak = [...topicMap]
    .map(([topic, v]) => ({
      topic,
      accuracy: Math.round((v.correct / v.total) * 100),
      total: v.total,
    }))
    .filter((t) => t.accuracy < 70)
    .sort((a, b) => a.accuracy - b.accuracy)
    .slice(0, 3);
  return (
    <div className="page-stack">
      <div className="dashboard-heading">
        <div>
          <p className="eyebrow">YOUR LEARNING, A LITTLE CLEARER</p>
          <h1>
            Welcome
            {name ? ` back, ${name.split(" ")[0]}` : " to your study space"}
            <span className="text-accent-strong">.</span>
          </h1>
          <p className="text-muted-foreground mt-2">
            A little curiosity goes a long way.
          </p>
        </div>
        <span className="date-label">
          {new Date().toLocaleDateString("en", {
            weekday: "long",
            month: "short",
            day: "numeric",
          })}
        </span>
      </div>
      <section className="hero-panel">
        <div className="hero-copy">
          <span className="chip hero-chip">
            <Sparkles size={13} /> MADE FOR YOUR NEXT “AHA”
          </span>
          <h2>
            Don’t just remember it.
            <br />
            <em>Understand it.</em>
          </h2>
          <p>
            A good question can change everything. Explore an idea with your AI
            tutor, one thoughtful step at a time.
          </p>
          <Button size="lg" onClick={() => navigate("tutor")}>
            Let’s explore <ArrowUpRight />
          </Button>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="orbit orbit-one" />
          <div className="orbit orbit-two" />
          <div className="orbit orbit-three" />
          <div className="art-center">
            a<span>✳</span>
          </div>
          <span className="art-star one">✳</span>
          <span className="art-star two">✧</span>
          <span className="art-dot" />
        </div>
        <span className="hero-caption">
          CURIOSITY IS THE BEGINNING OF WISDOM.
        </span>
      </section>
      <section className="stats-grid" aria-label="Your learning statistics">
        {[
          {
            icon: Flame,
            label: "Learning streak",
            value: studyStreak(data.activity),
            unit: "days",
            note: "Keep the curiosity going",
            color: "peach",
          },
          {
            icon: Timer,
            label: "Focus time",
            value: minutes >= 60 ? (minutes / 60).toFixed(1) : minutes,
            unit: minutes >= 60 ? "hrs" : "min",
            note: "Time invested in yourself",
            color: "lavender",
          },
          {
            icon: Target,
            label: "Quiz accuracy",
            value: total ? Math.round((correct / total) * 100) : "—",
            unit: total ? "%" : "",
            note: total
              ? `${total} questions answered`
              : "Your first quiz awaits",
            color: "sage",
          },
          {
            icon: Layers,
            label: "Cards to review",
            value: due,
            unit: "cards",
            note: due
              ? "A little recall, a lasting memory"
              : "All caught up for now",
            color: "sand",
          },
        ].map((item) => (
          <div className="stat-card" key={item.label}>
            <div className="flex items-center justify-between">
              <span className="stat-label">{item.label}</span>
              <span className={`stat-icon ${item.color}`}>
                <item.icon size={17} />
              </span>
            </div>
            <p className="stat-value">
              {item.value}
              <span>{item.unit}</span>
            </p>
            <p className="stat-note">{item.note}</p>
          </div>
        ))}
      </section>
      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Your learning rhythm</h2>
              <p>Small steps add up.</p>
            </div>
            <span className="chip">Last 7 days</span>
          </div>
          <div
            className="chart-container"
            role="img"
            aria-label={`Focus minutes over seven days: ${series.map((s) => `${s.day} ${s.minutes}`).join(", ")}`}
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={series}
                margin={{ top: 12, right: 8, left: -24, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="studyFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#9273c3" stopOpacity={0.22} />
                    <stop
                      offset="100%"
                      stopColor="#9273c3"
                      stopOpacity={0.01}
                    />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  vertical={false}
                  stroke="var(--border)"
                  strokeDasharray="3 4"
                />
                <XAxis
                  dataKey="day"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
                  dy={8}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
                  allowDecimals={false}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: 12,
                  }}
                  formatter={(value) => [`${value} min`, "Focus time"]}
                />
                <Area
                  type="monotone"
                  dataKey="minutes"
                  stroke="#8d68bc"
                  strokeWidth={2.5}
                  fill="url(#studyFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            {minutes
              ? "Every completed focus session counts."
              : "Complete a focus session to start your rhythm."}
          </p>
        </section>
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Today’s intentions</h2>
              <p>
                {today.length
                  ? `${completed} of ${today.length} complete`
                  : "Give your day a little direction."}
              </p>
            </div>
            <button
              className="icon-link"
              aria-label="Open study plan"
              onClick={() => navigate("plan")}
            >
              <ArrowUpRight size={20} />
            </button>
          </div>
          {today.length ? (
            <>
              <Progress
                value={(completed / today.length) * 100}
                label="Today's task completion"
              />
              <div className="task-list mt-5">
                {today.slice(0, 3).map((task) => (
                  <label key={task.id} className="task-row">
                    <input
                      type="checkbox"
                      checked={task.done}
                      onChange={() =>
                        store.update(
                          (prev) => ({
                            ...prev,
                            tasks: prev.tasks.map((t) =>
                              t.id === task.id ? { ...t, done: !t.done } : t,
                            ),
                          }),
                          true,
                        )
                      }
                    />
                    <span
                      className={
                        task.done ? "line-through text-muted-foreground" : ""
                      }
                    >
                      {task.title}
                      <small>{task.minutes} min</small>
                    </span>
                  </label>
                ))}
              </div>
            </>
          ) : (
            <div className="mini-empty">
              <span className="mini-illustration">
                <Check size={26} />
              </span>
              <h3>A plan makes space for progress.</h3>
              <p>Turn your exam date into manageable daily steps.</p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate("plan")}
              >
                Make a study plan <ArrowUpRight />
              </Button>
            </div>
          )}
        </section>
      </div>
      <section>
        <div className="panel-heading">
          <div>
            <h2>Pick up a little knowledge</h2>
            <p>Your materials, ready when you are.</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("materials")}
          >
            View all <ArrowUpRight />
          </Button>
        </div>
        <div className="materials-grid">
          {data.materials
            .slice(-2)
            .reverse()
            .map((material) => (
              <button
                className="material-tile text-left"
                key={material.id}
                onClick={() => {
                  chooseMaterial(material.id);
                  navigate("materials");
                }}
              >
                <span className="material-icon">
                  <FileText />
                </span>
                <span className="chip capitalize">{material.kind}</span>
                <h3>{material.title}</h3>
                <p>
                  {material.text.slice(0, 95)}
                  {material.text.length > 95 ? "…" : ""}
                </p>
                <span className="tile-footer">
                  Open material <ArrowUpRight size={16} />
                </span>
              </button>
            ))}
          <button className="add-material-tile" onClick={addMaterial}>
            <span>
              <Plus size={24} />
            </span>
            <h3>Add something to learn</h3>
            <p>A document, your notes, or just an idea.</p>
          </button>
        </div>
      </section>
      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Make it stick</h2>
              <p>A different way to put your knowledge to work.</p>
            </div>
          </div>
          <div className="quick-actions">
            {[
              {
                icon: MessageCircle,
                title: "Ask a better question",
                text: "Think it through with your tutor",
                view: "tutor",
              },
              {
                icon: Layers,
                title: "A little active recall",
                text: `${due} flashcards ready for review`,
                view: "flashcards",
              },
              {
                icon: BookOpen,
                title: "Check your understanding",
                text: "Take a quiz. Find your next step.",
                view: "quizzes",
              },
            ].map((a) => (
              <button key={a.view} onClick={() => navigate(a.view as View)}>
                <span className="quick-icon">
                  <a.icon size={19} />
                </span>
                <span>
                  <strong>{a.title}</strong>
                  <small>{a.text}</small>
                </span>
                <ArrowUpRight size={17} />
              </button>
            ))}
          </div>
        </section>
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Room to grow</h2>
              <p>Topics that could use another look.</p>
            </div>
            <Target size={18} className="text-muted-foreground" />
          </div>
          {weak.length ? (
            <div className="grid gap-5">
              {weak.map((t) => (
                <div key={t.topic}>
                  <div className="flex justify-between gap-3 mb-2 text-sm">
                    <span>{t.topic}</span>
                    <span>{t.accuracy}%</span>
                  </div>
                  <Progress
                    value={t.accuracy}
                    label={`${t.topic} quiz accuracy`}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Across {t.total} answered questions
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground py-8 leading-relaxed">
              {total
                ? "Looking good. No topics are below 70% accuracy. Keep testing your understanding."
                : "Your quiz results will help you see where a little more practice can make a difference."}
            </p>
          )}
        </section>
      </div>
      <footer className="page-footer">
        <span className="little-star">✳</span> Learning is a journey. You don’t
        have to rush it.
      </footer>
    </div>
  );
}
