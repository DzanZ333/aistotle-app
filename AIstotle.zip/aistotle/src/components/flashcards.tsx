"use client";
import { newId } from "@/lib/id";
import { useEffect, useState } from "react";
import {
  Layers,
  Plus,
  Sparkles,
  Pencil,
  Trash2,
  RotateCcw,
  CheckCircle2,
} from "lucide-react";
import type { StudyStore } from "@/hooks/use-workspace";
import type { Card } from "@/lib/schema";
import { reviewCard } from "@/lib/study";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Empty, Field, Notice, SectionTitle, Spinner } from "./ui/shared";
import { MaterialSelect, useGenerate } from "./materials";
import { Markdown } from "./markdown";
export function Flashcards({
  store,
  selected,
  onSelect,
}: {
  store: StudyStore;
  selected: string;
  onSelect: (id: string) => void;
}) {
  const [tab, setTab] = useState<"review" | "manage">("review"),
    [revealed, setRevealed] = useState(false),
    [editing, setEditing] = useState<Card | null>(null),
    [open, setOpen] = useState(false),
    [front, setFront] = useState(""),
    [back, setBack] = useState("");
  const { generate, busy, error } = useGenerate(store, selected);
  const cards = store.data.cards.filter(
    (c) => !selected || c.materialId === selected,
  );
  const due = cards
    .filter((c) => new Date(c.due) <= new Date())
    .sort((a, b) => a.due.localeCompare(b.due));
  const current = due[0];
  useEffect(() => setRevealed(false), [current?.id]);
  async function makeCards() {
    const materialId = selected || "subject";
    const result = await generate<{ cards: { front: string; back: string }[] }>(
      "cards",
    );
    if (result)
      store.update(
        (prev) => ({
          ...prev,
          cards: [
            ...prev.cards,
            ...result.cards.map((c) => ({
              ...c,
              id: newId(),
              materialId,
              ease: 2.5,
              interval: 0,
              repetitions: 0,
              due: new Date().toISOString(),
            })),
          ],
        }),
        true,
      );
  }
  function edit(card?: Card) {
    setEditing(card || null);
    setFront(card?.front || "");
    setBack(card?.back || "");
    setOpen(true);
  }
  function save(event: React.FormEvent) {
    event.preventDefault();
    const card: Card = {
      ...(editing || {
        id: newId(),
        materialId: selected || "subject",
        ease: 2.5,
        interval: 0,
        repetitions: 0,
        due: new Date().toISOString(),
      }),
      front: front.trim(),
      back: back.trim(),
    };
    if (
      store.update((prev) => ({
        ...prev,
        cards: editing
          ? prev.cards.map((c) => (c.id === card.id ? card : c))
          : [...prev.cards, card],
      }))
    )
      setOpen(false);
  }
  return (
    <div className="page-stack">
      <SectionTitle
        eyebrow="KNOW IT. RECALL IT. KEEP IT."
        title="Make it second nature."
        description="A little active recall today. A stronger memory tomorrow."
      />
      <div className="toolbar">
        <MaterialSelect store={store} value={selected} onChange={onSelect} />
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => edit()}>
            <Plus />
            Add card
          </Button>
          <Button disabled={busy} onClick={makeCards}>
            <Sparkles />
            Generate cards
          </Button>
        </div>
      </div>
      {error && (
        <Notice>
          {error}{" "}
          <button className="underline" onClick={makeCards} disabled={busy}>
            Retry
          </button>
        </Notice>
      )}
      {busy && <Spinner label="Turning ideas into recall questions…" />}
      <div className="flex justify-between items-center gap-4">
        <div className="segmented">
          <button
            className={tab === "review" ? "active" : ""}
            onClick={() => setTab("review")}
          >
            Review <span className="count-badge">{due.length}</span>
          </button>
          <button
            className={tab === "manage" ? "active" : ""}
            onClick={() => setTab("manage")}
          >
            All cards <span className="count-badge">{cards.length}</span>
          </button>
        </div>
        <span className="text-xs text-muted-foreground hidden sm:block">
          Spaced repetition · SM-2
        </span>
      </div>
      {tab === "review" ? (
        current ? (
          <div className="review-space">
            <div className="flashcard">
              <p className="eyebrow">
                {revealed ? "THE OTHER SIDE" : "A MOMENT TO REMEMBER"}
              </p>
              <div className="card-question">
                <Markdown>{current.front}</Markdown>
              </div>
              {revealed && (
                <div className="card-answer">
                  <Markdown>{current.back}</Markdown>
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                {revealed
                  ? "How easily did you recall this?"
                  : "Try answering out loud before you turn it over."}
              </p>
            </div>
            {!revealed ? (
              <Button size="lg" onClick={() => setRevealed(true)}>
                <RotateCcw />
                Reveal answer
              </Button>
            ) : (
              <div className="rating-buttons">
                {[
                  { quality: 1, label: "Again", help: "I forgot" },
                  { quality: 3, label: "Hard", help: "With effort" },
                  { quality: 4, label: "Good", help: "I knew it" },
                  { quality: 5, label: "Easy", help: "Right away" },
                ].map((r) => (
                  <button
                    key={r.quality}
                    onClick={() => {
                      store.update(
                        (prev) => ({
                          ...prev,
                          cards: prev.cards.map((c) =>
                            c.id === current.id ? reviewCard(c, r.quality) : c,
                          ),
                        }),
                        true,
                      );
                      setRevealed(false);
                    }}
                  >
                    <strong>{r.label}</strong>
                    <small>{r.help}</small>
                  </button>
                ))}
              </div>
            )}
            <p className="text-sm text-muted-foreground">
              {due.length} {due.length === 1 ? "card" : "cards"} ready for
              review
            </p>
          </div>
        ) : (
          <div className="panel">
            <Empty
              icon={cards.length ? CheckCircle2 : Layers}
              title={
                cards.length
                  ? "A good place to pause."
                  : "Give your memory something to work with."
              }
              description={
                cards.length
                  ? "You’ve reviewed every card due now. Your next review will appear here when it’s time."
                  : "Generate cards from a topic or material, or create your own."
              }
              action={cards.length ? undefined : "Add a card"}
              onAction={() => edit()}
            />
          </div>
        )
      ) : (
        <div className="panel">
          {cards.length ? (
            <div className="card-management">
              {cards.map((card) => (
                <div key={card.id} className="card-management-row">
                  <div>
                    <Markdown>{card.front}</Markdown>
                    <p className="mt-2 text-xs text-muted-foreground">
                      Due {new Date(card.due).toLocaleDateString()} ·{" "}
                      {card.repetitions} successful reviews · {card.interval}{" "}
                      day interval
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      aria-label="Edit card"
                      onClick={() => edit(card)}
                    >
                      <Pencil />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      aria-label="Delete card"
                      onClick={() => {
                        if (window.confirm("Delete this flashcard?"))
                          store.update((prev) => ({
                            ...prev,
                            cards: prev.cards.filter((c) => c.id !== card.id),
                          }));
                      }}
                    >
                      <Trash2 />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <Empty
              icon={Layers}
              title="No cards yet."
              description="Add a card or generate a set to get started."
            />
          )}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogTitle className="text-xl font-semibold">
            {editing ? "Refine this card" : "One idea, one card."}
          </DialogTitle>
          <DialogDescription className="mt-2 mb-5 text-muted-foreground">
            Keep the question focused and the answer clear.
          </DialogDescription>
          <form className="grid gap-4" onSubmit={save}>
            <Field label="Front — the question">
              <textarea
                value={front}
                onChange={(e) => setFront(e.target.value)}
                rows={3}
                maxLength={1000}
                required
              />
            </Field>
            <Field label="Back — the answer">
              <textarea
                value={back}
                onChange={(e) => setBack(e.target.value)}
                rows={5}
                maxLength={3000}
                required
              />
            </Field>
            <Button type="submit">Save card</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
