"use client";
import { newId } from "@/lib/id";
import { useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Coffee, Timer } from "lucide-react";
import { z } from "zod";
import type { StudyStore } from "@/hooks/use-workspace";
import { localDay } from "@/lib/study";
import { Button } from "./ui/button";
import { Notice, SectionTitle } from "./ui/shared";
const timerSchema = z.object({
  id: z.string(),
  mode: z.enum(["focus", "break"]),
  duration: z.number().min(1).max(120),
  remaining: z.number().min(0).max(7200),
  deadline: z.number().nullable(),
  cycles: z.number().int().min(0),
  subject: z.string().max(150),
});
type TimerState = z.infer<typeof timerSchema>;
export function Focus({
  store,
  active,
}: {
  store: StudyStore;
  active: boolean;
}) {
  const key = `aistotle:timer:${store.owner}`;
  const [timer, setTimer] = useState<TimerState>({
    id: newId(),
    mode: "focus",
    duration: 25,
    remaining: 1500,
    deadline: null,
    cycles: 0,
    subject: store.data.profile.subject,
  });
  const [ready, setReady] = useState(false),
    [error, setError] = useState(""),
    [announcement, setAnnouncement] = useState("");
  const latest = useRef(timer),
    completed = useRef(new Set<string>());
  latest.current = timer;
  useEffect(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const result = timerSchema.safeParse(JSON.parse(raw));
        if (result.success) setTimer(result.data);
      }
    } catch {
      setError(
        "Timer recovery is unavailable on this device. Keep this page open during your session.",
      );
    }
    setReady(true);
  }, [key]);
  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(key, JSON.stringify(timer));
    } catch {
      setError(
        "The timer could not be saved on this device. Keep this page open.",
      );
    }
  }, [timer, key, ready]);
  useEffect(() => {
    if (!ready) return;
    const tick = () => {
      const state = latest.current;
      if (!state.deadline) return;
      const remaining = Math.max(
        0,
        Math.ceil((state.deadline - Date.now()) / 1000),
      );
      if (remaining > 0) {
        setTimer((prev) => ({ ...prev, remaining }));
        return;
      }
      if (completed.current.has(state.id)) return;
      completed.current.add(state.id);
      if (state.mode === "focus")
        store.update((prev) =>
          prev.focus.some((f) => f.id === state.id)
            ? prev
            : {
                ...prev,
                focus: [
                  ...prev.focus,
                  {
                    id: state.id,
                    createdAt: new Date(state.deadline!).toISOString(),
                    minutes: state.duration,
                    subject: state.subject,
                  },
                ].slice(-3000),
                activity: [
                  ...new Set([
                    ...prev.activity,
                    localDay(new Date(state.deadline!)),
                  ]),
                ]
                  .sort()
                  .slice(-3660),
              },
        );
      const cycles = state.cycles + Number(state.mode === "focus");
      const mode = state.mode === "focus" ? "break" : "focus";
      const duration = mode === "break" ? (cycles % 4 === 0 ? 15 : 5) : 25;
      setTimer({
        id: newId(),
        mode,
        duration,
        remaining: duration * 60,
        deadline: null,
        cycles,
        subject: store.data.profile.subject,
      });
      setAnnouncement(
        mode === "break"
          ? "Session complete. Your focus time is saved. Take a breath and start your break."
          : "Break complete. Ready for another small step?",
      );
    };
    tick();
    const interval = setInterval(tick, 500);
    return () => clearInterval(interval);
  }, [ready, store.update, store.data.profile.subject]);
  const today = store.data.focus.filter(
    (f) => localDay(new Date(f.createdAt)) === localDay(),
  );
  const clock = `${String(Math.floor(timer.remaining / 60)).padStart(2, "0")}:${String(timer.remaining % 60).padStart(2, "0")}`;
  function configure(mode: "focus" | "break", duration: number) {
    if (timer.deadline) return;
    setTimer((prev) => ({
      ...prev,
      id: newId(),
      mode,
      duration,
      remaining: duration * 60,
      deadline: null,
    }));
    setAnnouncement("");
  }
  return (
    <div hidden={!active} className="page-stack">
      <SectionTitle
        eyebrow="ONE THING AT A TIME"
        title="A little room to focus."
        description="Settle in. Let everything else wait for a while."
      />
      {error && <Notice>{error}</Notice>}
      {announcement && <Notice tone="success">{announcement}</Notice>}
      <section className="focus-panel panel">
        <div className="segmented">
          <button
            className={timer.mode === "focus" ? "active" : ""}
            disabled={Boolean(timer.deadline)}
            onClick={() => configure("focus", 25)}
          >
            <Timer size={16} />
            Focus
          </button>
          <button
            className={timer.mode === "break" ? "active" : ""}
            disabled={Boolean(timer.deadline)}
            onClick={() => configure("break", 5)}
          >
            <Coffee size={16} />
            Short break
          </button>
          <button
            className={
              timer.mode === "break" && timer.duration === 15 ? "active" : ""
            }
            disabled={Boolean(timer.deadline)}
            onClick={() => configure("break", 15)}
          >
            Long break
          </button>
        </div>
        <div
          className="timer-orbit"
          style={
            {
              "--progress": `${(1 - timer.remaining / (timer.duration * 60)) * 360}deg`,
            } as React.CSSProperties
          }
        >
          <div className="timer-face">
            <p className="eyebrow">
              {timer.mode === "focus" ? "BE HERE, NOW" : "BREATHE A LITTLE"}
            </p>
            <p
              className="timer-digits"
              role="timer"
              aria-label={`${Math.floor(timer.remaining / 60)} minutes ${timer.remaining % 60} seconds remaining`}
            >
              {clock}
            </p>
            <span>
              {timer.deadline
                ? "One moment at a time."
                : "Whenever you’re ready."}
            </span>
          </div>
        </div>
        <label className="focus-subject">
          Focusing on
          <input
            aria-label="Focus subject"
            value={timer.subject}
            disabled={Boolean(timer.deadline)}
            onChange={(e) =>
              setTimer((prev) => ({ ...prev, subject: e.target.value }))
            }
            maxLength={150}
          />
        </label>
        <div className="flex gap-3">
          <Button
            size="lg"
            onClick={() => {
              setAnnouncement("");
              setTimer((prev) => ({
                ...prev,
                deadline: prev.deadline
                  ? null
                  : Date.now() + prev.remaining * 1000,
              }));
            }}
          >
            {timer.deadline ? <Pause /> : <Play />}
            {timer.deadline
              ? "Pause"
              : timer.remaining === timer.duration * 60
                ? "Start session"
                : "Continue"}
          </Button>
          <Button
            variant="outline"
            size="lg"
            aria-label="Reset timer"
            onClick={() => {
              setTimer((prev) => ({
                ...prev,
                id: newId(),
                remaining: prev.duration * 60,
                deadline: null,
              }));
              setAnnouncement("");
            }}
          >
            <RotateCcw />
          </Button>
        </div>
        {timer.mode === "focus" && (
          <div className="flex gap-2 mt-2">
            {[25, 50, 90].map((minutes) => (
              <button
                className={`chip ${timer.duration === minutes ? "selected" : ""}`}
                key={minutes}
                disabled={Boolean(timer.deadline)}
                onClick={() => configure("focus", minutes)}
              >
                {minutes} min
              </button>
            ))}
          </div>
        )}
        <p className="text-xs text-muted-foreground max-w-sm text-center">
          Only completed focus sessions count. Breaks start when you’re ready;
          every fourth break is 15 minutes.
        </p>
      </section>
      <div className="focus-stats">
        <div className="panel">
          <p className="eyebrow">TODAY’S SESSIONS</p>
          <strong>{today.length}</strong>
          <p>Small commitments kept.</p>
        </div>
        <div className="panel">
          <p className="eyebrow">TODAY’S FOCUS</p>
          <strong>
            {today.reduce((sum, f) => sum + f.minutes, 0)} <small>min</small>
          </strong>
          <p>Time you made for learning.</p>
        </div>
        <div className="panel">
          <p className="eyebrow">ALL-TIME SESSIONS</p>
          <strong>{store.data.focus.length}</strong>
          <p>Every session is a step.</p>
        </div>
      </div>
    </div>
  );
}
