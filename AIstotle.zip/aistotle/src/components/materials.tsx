"use client";
import { newId } from "@/lib/id";
import { useState } from "react";
import {
  BookOpen,
  FileText,
  Upload,
  AlignLeft,
  Lightbulb,
  Trash2,
  Sparkles,
  MessageCircle,
} from "lucide-react";
import type { StudyStore } from "@/hooks/use-workspace";
import type { Material } from "@/lib/schema";
import { api } from "@/lib/utils";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Empty, Field, Notice, SectionTitle, Spinner } from "./ui/shared";
import { Markdown } from "./markdown";
export function MaterialSelect({
  store,
  value,
  onChange,
}: {
  store: StudyStore;
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <label className="material-select">
      <span>Learning from</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-label="Study material"
      >
        <option value="">My subject: {store.data.profile.subject}</option>
        {store.data.materials.map((m) => (
          <option value={m.id} key={m.id}>
            {m.title}
          </option>
        ))}
      </select>
    </label>
  );
}
export function useGenerate(store: StudyStore, materialId: string) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function generate<T>(
    mode: "summary" | "cards" | "quiz",
  ): Promise<T | undefined> {
    setBusy(true);
    setError("");
    const material = store.data.materials.find((m) => m.id === materialId);
    try {
      return await api<T>("/api/ai", {
        method: "POST",
        body: JSON.stringify({
          mode,
          title: material?.title || store.data.profile.subject,
          material: material?.text || store.data.profile.subject,
          level: store.data.profile.level,
          goal: store.data.profile.goal,
          messages: [],
        }),
      });
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Could not generate this study aid.",
      );
    } finally {
      setBusy(false);
    }
  }
  return { generate, busy, error };
}
export function AddMaterial({
  store,
  open,
  onOpenChange,
  onAdded,
}: {
  store: StudyStore;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onAdded: (id: string) => void;
}) {
  const [mode, setMode] = useState<"text" | "topic" | "file">("text"),
    [title, setTitle] = useState(""),
    [content, setContent] = useState(""),
    [file, setFile] = useState<File | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function save(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      let text = content.trim(),
        name = title.trim();
      if (mode === "file") {
        if (!file) throw new Error("Choose a file first.");
        if (file.size > 4 * 1024 * 1024)
          throw new Error("Choose a file smaller than 4 MiB.");
        const response = await fetch(
          `/api/materials?name=${encodeURIComponent(file.name)}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/octet-stream" },
            body: file,
          },
        );
        const result = await response.json();
        if (!response.ok) throw new Error(result.error);
        text = result.text;
        name = name || result.title;
      }
      if (mode === "topic") {
        text = name;
        if (!name) throw new Error("Name a topic you would like to explore.");
      }
      if (!text) throw new Error("Add some study material first.");
      if (!name) name = text.slice(0, 70);
      const material: Material = {
        id: newId(),
        title: name,
        text,
        kind: mode,
        createdAt: new Date().toISOString(),
      };
      if (
        !store.update(
          (prev) => ({ ...prev, materials: [...prev.materials, material] }),
          true,
        )
      )
        throw new Error(
          "Your workspace has reached its limit. Remove an older material and retry.",
        );
      onAdded(material.id);
      onOpenChange(false);
      setTitle("");
      setContent("");
      setFile(null);
    } catch (error) {
      setError(
        error instanceof Error ? error.message : "Could not add this material.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogTitle className="text-2xl font-semibold">
          Bring your curiosity.
        </DialogTitle>
        <DialogDescription className="mt-2 mb-5 text-muted-foreground">
          Turn what you have into something you understand.
        </DialogDescription>
        <div className="segmented mb-5">
          {[
            { id: "text", label: "Paste text", icon: AlignLeft },
            { id: "file", label: "Upload", icon: Upload },
            { id: "topic", label: "A topic", icon: Lightbulb },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={mode === item.id}
              className={mode === item.id ? "active" : ""}
              onClick={() => {
                setMode(item.id as typeof mode);
                setError("");
              }}
            >
              <item.icon size={16} />
              {item.label}
            </button>
          ))}
        </div>
        {error && <Notice>{error}</Notice>}
        <form className="grid gap-5" onSubmit={save}>
          <Field
            label={mode === "topic" ? "What would you like to learn?" : "Title"}
          >
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={150}
              required={mode === "topic"}
              placeholder={
                mode === "topic"
                  ? "e.g. The accounting equation"
                  : "Give these notes a name"
              }
            />
          </Field>
          {mode === "text" && (
            <Field
              label="Your notes"
              hint={`${content.length.toLocaleString()} / 60,000 characters`}
            >
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                maxLength={60000}
                rows={8}
                required
                placeholder="Paste your lecture notes, a chapter, or a passage…"
              />
            </Field>
          )}
          {mode === "file" && (
            <Field
              label="Choose a document"
              hint="PDF, TXT, or DOCX · up to 4 MiB · PDF up to 100 pages. Scanned PDFs require OCR first."
            >
              <div className="upload-zone">
                <Upload className="mx-auto mb-3 text-accent-strong" />
                <input
                  type="file"
                  accept=".pdf,.txt,.docx"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  required
                />
                <p className="text-xs mt-3 text-muted-foreground">
                  We keep the extracted text; the original file is not stored.
                </p>
              </div>
            </Field>
          )}
          <Button size="lg" type="submit" disabled={busy}>
            {busy ? "Reading your material…" : "Add to my materials"}
            <BookOpen />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
export function Materials({
  store,
  selected,
  onSelect,
  onAdd,
  onTutor,
}: {
  store: StudyStore;
  selected: string;
  onSelect: (id: string) => void;
  onAdd: () => void;
  onTutor: () => void;
}) {
  const material = store.data.materials.find((m) => m.id === selected);
  const { generate, busy, error } = useGenerate(store, selected);
  const [showSource, setShowSource] = useState(false);
  async function summarize() {
    const id = selected;
    const summary = await generate<NonNullable<Material["summary"]>>("summary");
    if (summary)
      store.update(
        (prev) => ({
          ...prev,
          materials: prev.materials.map((m) =>
            m.id === id ? { ...m, summary } : m,
          ),
        }),
        true,
      );
  }
  function remove(id: string) {
    if (
      !window.confirm(
        "Delete this material and its related cards, quizzes, attempts, and chat messages?",
      )
    )
      return;
    store.update((prev) => {
      const quizIds = prev.quizzes
        .filter((q) => q.materialId === id)
        .map((q) => q.id);
      return {
        ...prev,
        materials: prev.materials.filter((m) => m.id !== id),
        cards: prev.cards.filter((c) => c.materialId !== id),
        quizzes: prev.quizzes.filter((q) => q.materialId !== id),
        attempts: prev.attempts.filter((a) => !quizIds.includes(a.quizId)),
        messages: prev.messages.filter((m) => m.materialId !== id),
      };
    });
    onSelect("");
  }
  return (
    <div className="page-stack">
      <SectionTitle
        eyebrow="YOUR KNOWLEDGE SHELF"
        title="A place for every idea."
        description="Notes become understanding when you make them your own."
        action="Add material"
        onAction={onAdd}
      />
      {!store.data.materials.length ? (
        <div className="panel">
          <Empty
            icon={BookOpen}
            title="Your first idea belongs here."
            description="Upload your notes, paste a passage, or name a topic. We’ll take it from there."
            action="Add your first material"
            onAction={onAdd}
          />
        </div>
      ) : (
        <div className="library-layout">
          <aside className="material-list panel">
            {store.data.materials.map((m) => (
              <button
                key={m.id}
                className={`material-list-item ${selected === m.id ? "selected" : ""}`}
                onClick={() => {
                  onSelect(m.id);
                  setShowSource(false);
                }}
              >
                <FileText size={20} />
                <span>
                  <strong>{m.title}</strong>
                  <small>
                    {m.kind === "topic"
                      ? "Topic"
                      : `${m.text.length.toLocaleString()} characters`}{" "}
                    · {new Date(m.createdAt).toLocaleDateString()}
                  </small>
                </span>
              </button>
            ))}
          </aside>
          <section className="panel min-w-0">
            {material ? (
              <>
                <div className="panel-heading">
                  <div>
                    <span className="chip capitalize mb-3">
                      {material.kind}
                    </span>
                    <h2 className="text-xl">{material.title}</h2>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label={`Delete ${material.title}`}
                    onClick={() => remove(material.id)}
                  >
                    <Trash2 />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mb-6">
                  <Button onClick={summarize} disabled={busy}>
                    <Sparkles />
                    {material.summary
                      ? "Regenerate summary"
                      : "Make sense of it"}
                  </Button>
                  <Button variant="outline" onClick={onTutor}>
                    <MessageCircle />
                    Ask my tutor
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => setShowSource(!showSource)}
                  >
                    {showSource ? "Hide source" : "Read source"}
                  </Button>
                </div>
                {error && (
                  <Notice>
                    {error}{" "}
                    <button
                      className="underline"
                      disabled={busy}
                      onClick={summarize}
                    >
                      Retry
                    </button>
                  </Notice>
                )}
                {busy ? (
                  <Spinner label="Finding the ideas that matter…" />
                ) : showSource ? (
                  <div className="source-text">{material.text}</div>
                ) : material.summary ? (
                  <div className="summary-content">
                    <p className="eyebrow mb-3">THE BIG PICTURE</p>
                    <Markdown>{material.summary.summary}</Markdown>
                    <h3 className="mt-7 mb-3 font-semibold">Key concepts</h3>
                    <ul className="concept-list">
                      {material.summary.concepts.map((concept, i) => (
                        <li key={i}>
                          <span>{String(i + 1).padStart(2, "0")}</span>
                          <Markdown>{concept}</Markdown>
                        </li>
                      ))}
                    </ul>
                    <h3 className="mt-7 mb-3 font-semibold">
                      A little glossary
                    </h3>
                    <dl className="glossary">
                      {material.summary.glossary.map((entry, i) => (
                        <div key={i}>
                          <dt>{entry.term}</dt>
                          <dd>{entry.definition}</dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                ) : (
                  <Empty
                    icon={Lightbulb}
                    title="Find the thread."
                    description="Generate a short summary, key concepts, and a glossary from this material."
                  />
                )}
              </>
            ) : (
              <Empty
                icon={FileText}
                title="Pick an idea to explore."
                description="Choose a material from your shelf to see the bigger picture."
              />
            )}
          </section>
        </div>
      )}
    </div>
  );
}
