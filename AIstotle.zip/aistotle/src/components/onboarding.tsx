"use client";
import { useState } from "react";
import type { StudyStore } from "@/hooks/use-workspace";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Field } from "./ui/shared";
export function Onboarding({
  store,
  open,
  onOpenChange,
}: {
  store: StudyStore;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [subject, setSubject] = useState(""),
    [level, setLevel] = useState<"beginner" | "intermediate" | "advanced">(
      "beginner",
    ),
    [goal, setGoal] = useState(
      "Understand the concepts, not just memorize them",
    );
  function save(event: React.FormEvent) {
    event.preventDefault();
    if (
      store.update((prev) => ({
        ...prev,
        profile: {
          subject: subject.trim() || "General learning",
          level,
          goal: goal.trim(),
          onboarded: true,
        },
      }))
    )
      onOpenChange(false);
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <p className="eyebrow mb-3">A SMALL START. A BIG POSSIBILITY.</p>
        <DialogTitle className="text-3xl font-semibold tracking-tight">
          What are you curious about?
        </DialogTitle>
        <DialogDescription className="mt-3 mb-6 text-muted-foreground">
          Let’s make this study space yours. You can change these anytime.
        </DialogDescription>
        <form onSubmit={save} className="grid gap-5">
          <Field label="Your subject">
            <input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g. Biology, accounting, computer science"
              maxLength={100}
              required
            />
          </Field>
          <div className="flex flex-wrap gap-2">
            {["Biology", "Accounting", "Management", "Computer science"].map(
              (s) => (
                <button
                  key={s}
                  type="button"
                  className="chip"
                  onClick={() => setSubject(s)}
                >
                  {s}
                </button>
              ),
            )}
          </div>
          <Field label="Your starting point">
            <select
              value={level}
              onChange={(e) => setLevel(e.target.value as typeof level)}
            >
              <option value="beginner">
                Beginner — start with the foundations
              </option>
              <option value="intermediate">
                Intermediate — connect the ideas
              </option>
              <option value="advanced">
                Advanced — challenge my understanding
              </option>
            </select>
          </Field>
          <Field label="Your learning goal">
            <input
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              maxLength={300}
              required
            />
          </Field>
          <Button size="lg" type="submit">
            Create my study space <span aria-hidden="true">↗</span>
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
