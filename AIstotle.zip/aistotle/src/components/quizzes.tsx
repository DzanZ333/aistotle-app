"use client";
import { newId } from "@/lib/id";
import { useState } from "react";
import {
  Sparkles,
  ClipboardCheck,
  CheckCircle2,
  XCircle,
  ArrowRight,
  RotateCcw,
} from "lucide-react";
import type { StudyStore } from "@/hooks/use-workspace";
import type { Quiz, Question } from "@/lib/schema";
import { scoreAnswer, scoreQuiz } from "@/lib/study";
import { Button } from "./ui/button";
import { Empty, Notice, Progress, SectionTitle, Spinner } from "./ui/shared";
import { MaterialSelect, useGenerate } from "./materials";
import { Markdown } from "./markdown";
export function Quizzes({
  store,
  selected,
  onSelect,
}: {
  store: StudyStore;
  selected: string;
  onSelect: (id: string) => void;
}) {
  const [active, setActive] = useState<Quiz | null>(null),
    [index, setIndex] = useState(0),
    [answers, setAnswers] = useState<Record<string, string>>({}),
    [draft, setDraft] = useState(""),
    [finished, setFinished] = useState(false);
  const { generate, busy, error } = useGenerate(store, selected);
  const question = active?.questions[index];
  const answered = question && Object.hasOwn(answers, question.id);
  const correct = question
    ? scoreAnswer(question, answers[question.id] || "")
    : false;
  function begin(quiz: Quiz) {
    setActive(quiz);
    setIndex(0);
    setAnswers({});
    setDraft("");
    setFinished(false);
  }
  async function makeQuiz() {
    const materialId = selected || "subject";
    const title =
      store.data.materials.find((m) => m.id === selected)?.title ||
      store.data.profile.subject;
    const result = await generate<{ questions: Question[] }>("quiz");
    if (result) {
      const quiz: Quiz = {
        id: newId(),
        materialId,
        title,
        createdAt: new Date().toISOString(),
        questions: result.questions,
      };
      if (
        store.update(
          (prev) => ({ ...prev, quizzes: [...prev.quizzes, quiz] }),
          true,
        )
      )
        begin(quiz);
    }
  }
  function recordAnswer(value: string) {
    if (!question || answered || !value.trim()) return;
    setAnswers((prev) => ({ ...prev, [question.id]: value.trim() }));
  }
  function next() {
    if (!active) return;
    if (index < active.questions.length - 1) {
      setIndex(index + 1);
      setDraft("");
    } else {
      const result = scoreQuiz(active.questions, answers);
      if (
        store.update(
          (prev) => ({
            ...prev,
            attempts: [
              ...prev.attempts,
              {
                ...result,
                id: newId(),
                quizId: active.id,
                createdAt: new Date().toISOString(),
                answers,
              },
            ].slice(-500),
          }),
          true,
        )
      )
        setFinished(true);
    }
  }
  const visible = store.data.quizzes.filter(
    (q) => !selected || q.materialId === selected,
  );
  return (
    <div className="page-stack">
      <SectionTitle
        eyebrow="PROGRESS STARTS WITH A QUESTION"
        title="See what’s clicking."
        description="Find your strengths, revisit the gaps, and keep moving forward."
      />
      <div className="toolbar">
        <MaterialSelect store={store} value={selected} onChange={onSelect} />
        <Button onClick={makeQuiz} disabled={busy}>
          <Sparkles />
          Create a quiz
        </Button>
      </div>
      {error && (
        <Notice>
          {error}{" "}
          <button className="underline" disabled={busy} onClick={makeQuiz}>
            Retry
          </button>
        </Notice>
      )}
      {busy && <Spinner label="Preparing a thoughtful mix of questions…" />}
      {active ? (
        finished ? (
          <div className="panel quiz-result">
            <span className="empty-icon">
              <CheckCircle2 size={30} />
            </span>
            <p className="eyebrow">ANOTHER STEP FORWARD</p>
            <h2>
              {scoreQuiz(active.questions, answers).correct}{" "}
              <span>/ {active.questions.length}</span>
            </h2>
            <h3>
              {scoreQuiz(active.questions, answers).correct ===
              active.questions.length
                ? "It’s coming together."
                : "Now you know what to explore next."}
            </h3>
            <p>
              Your score is saved. Revisit explanations below, or take another
              pass.
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              <Button onClick={() => begin(active)}>
                <RotateCcw />
                Try again
              </Button>
              <Button variant="outline" onClick={() => setActive(null)}>
                Back to quizzes
              </Button>
            </div>
            <div className="text-left mt-8 grid gap-5">
              {active.questions.map((q) => (
                <div className="review-answer" key={q.id}>
                  <strong>
                    {scoreAnswer(q, answers[q.id] || "") ? "✓" : "↺"} {q.prompt}
                  </strong>
                  <p className="text-sm mt-2">
                    Your answer: {answers[q.id]} · Correct answer: {q.answer}
                  </p>
                  <div className="mt-2">
                    <Markdown>{q.explanation}</Markdown>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          question && (
            <section className="panel quiz-panel">
              <div className="flex justify-between mb-4 text-sm">
                <span>
                  Question {index + 1} of {active.questions.length}
                </span>
                <span className="chip">
                  {question.type.replaceAll("-", " ")}
                </span>
              </div>
              <Progress
                value={
                  ((index + Number(Boolean(answered))) /
                    active.questions.length) *
                  100
                }
                label="Quiz progress"
              />
              <div className="quiz-question">
                <Markdown>{question.prompt}</Markdown>
              </div>
              {question.type === "short-answer" ? (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    recordAnswer(draft);
                  }}
                  className="grid gap-3"
                >
                  <label className="text-sm font-medium" htmlFor="short-answer">
                    Your answer
                  </label>
                  <input
                    id="short-answer"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    maxLength={1000}
                    disabled={Boolean(answered)}
                    placeholder="A word or short phrase…"
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    Checked against the answer and listed alternatives; spelling
                    and phrasing can affect your score.
                  </p>
                  {!answered && (
                    <Button className="justify-self-start" type="submit">
                      Check answer
                    </Button>
                  )}
                </form>
              ) : (
                <div className="quiz-options">
                  {question.options.map((option, i) => (
                    <button
                      className={`${answered && option === question.answer ? "correct" : ""} ${answered && answers[question.id] === option && !correct ? "incorrect" : ""}`}
                      disabled={Boolean(answered)}
                      onClick={() => recordAnswer(option)}
                      key={option}
                    >
                      <span>{String.fromCharCode(65 + i)}</span>
                      {option}
                    </button>
                  ))}
                </div>
              )}
              {answered && (
                <div className="mt-6">
                  <Notice tone={correct ? "success" : "info"}>
                    <div className="flex items-center gap-2 font-semibold mb-2">
                      {correct ? (
                        <CheckCircle2 size={18} />
                      ) : (
                        <XCircle size={18} />
                      )}{" "}
                      {correct ? "That’s right." : "A useful moment to learn."}
                    </div>
                    {!correct && (
                      <p className="mb-2">Correct answer: {question.answer}</p>
                    )}
                    <Markdown>{question.explanation}</Markdown>
                  </Notice>
                  <Button className="mt-4" onClick={next}>
                    {index === active.questions.length - 1
                      ? "See my results"
                      : "Next question"}
                    <ArrowRight />
                  </Button>
                </div>
              )}
              <button
                className="text-sm underline mt-6 text-muted-foreground"
                onClick={() => {
                  if (
                    window.confirm(
                      "Leave this attempt? Unfinished answers will not be scored.",
                    )
                  )
                    setActive(null);
                }}
              >
                Leave quiz
              </button>
            </section>
          )
        )
      ) : (
        <section className="panel">
          {visible.length ? (
            <div className="saved-quizzes">
              {visible
                .slice()
                .reverse()
                .map((quiz) => (
                  <div key={quiz.id}>
                    <span className="material-icon">
                      <ClipboardCheck />
                    </span>
                    <div>
                      <h3>{quiz.title}</h3>
                      <p>
                        {quiz.questions.length} questions ·{" "}
                        {new Date(quiz.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => begin(quiz)}
                    >
                      Start <ArrowRight />
                    </Button>
                  </div>
                ))}
            </div>
          ) : (
            <Empty
              icon={ClipboardCheck}
              title="What do you know so far?"
              description="Create a quiz with multiple choice, true or false, and short-answer questions. Every answer is a chance to learn."
            />
          )}
        </section>
      )}
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h2>Your progress, one quiz at a time</h2>
            <p>Completed attempts are saved automatically.</p>
          </div>
        </div>
        {store.data.attempts.length ? (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Quiz</th>
                  <th>Date</th>
                  <th>Score</th>
                  <th>Accuracy</th>
                </tr>
              </thead>
              <tbody>
                {store.data.attempts
                  .slice(-20)
                  .reverse()
                  .map((attempt) => (
                    <tr key={attempt.id}>
                      <td>
                        {store.data.quizzes.find((q) => q.id === attempt.quizId)
                          ?.title || "Archived quiz"}
                      </td>
                      <td>
                        {new Date(attempt.createdAt).toLocaleDateString()}
                      </td>
                      <td>
                        {attempt.correct}/{attempt.total}
                      </td>
                      <td>
                        <span className="chip">
                          {Math.round((attempt.correct / attempt.total) * 100)}%
                        </span>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground py-4">
            Your first completed quiz will appear here.
          </p>
        )}
      </section>
    </div>
  );
}
