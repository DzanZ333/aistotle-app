"use client";
import { useState } from "react";
import { useTheme } from "next-themes";
import { Download, Upload, UserRound } from "lucide-react";
import { GUEST_KEY, type StudyStore } from "@/hooks/use-workspace";
import { workspaceSchema } from "@/lib/schema";
import { Button } from "./ui/button";
import { Field, Notice, SectionTitle } from "./ui/shared";
export function Settings({
  store,
  onLogin,
}: {
  store: StudyStore;
  onLogin: () => void;
}) {
  const { theme, setTheme } = useTheme();
  const [profile, setProfile] = useState(store.data.profile),
    [notice, setNotice] = useState(""),
    [error, setError] = useState("");
  function save(event: React.FormEvent) {
    event.preventDefault();
    if (
      store.update((prev) => ({
        ...prev,
        profile: { ...profile, onboarded: true },
      }))
    )
      setNotice("Your learning preferences are updated.");
  }
  function importData(text: string) {
    const parsed = workspaceSchema.safeParse(JSON.parse(text));
    if (!parsed.success)
      throw new Error("This file is not a valid AIstotle backup.");
    if (
      !window.confirm(
        "Replace this workspace with the imported data? Export your current workspace first if you want to keep it.",
      )
    )
      return;
    if (store.update(() => parsed.data))
      setNotice("Your study backup has been imported.");
  }
  async function importFile(file?: File) {
    if (!file) return;
    setError("");
    try {
      if (file.size > 4_000_000) throw new Error("Backups must be under 4 MB.");
      importData(await file.text());
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Could not import this backup.",
      );
    }
  }
  return (
    <div className="page-stack">
      <SectionTitle
        eyebrow="A SPACE THAT FITS YOU"
        title="Make yourself at home."
        description="Learning preferences, your account, and a little peace of mind."
      />
      {notice && <Notice tone="success">{notice}</Notice>}
      {error && <Notice>{error}</Notice>}
      <div className="settings-grid">
        <section className="panel">
          <div className="panel-heading">
            <h2>How you like to learn</h2>
          </div>
          <form onSubmit={save} className="grid gap-5">
            <Field label="Your subject">
              <input
                value={profile.subject}
                onChange={(e) =>
                  setProfile({ ...profile, subject: e.target.value })
                }
                required
                maxLength={100}
              />
            </Field>
            <Field label="Your level">
              <select
                value={profile.level}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    level: e.target.value as typeof profile.level,
                  })
                }
              >
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </Field>
            <Field label="Your goal">
              <textarea
                value={profile.goal}
                onChange={(e) =>
                  setProfile({ ...profile, goal: e.target.value })
                }
                required
                maxLength={300}
                rows={3}
              />
            </Field>
            <Button type="submit">Save preferences</Button>
          </form>
        </section>
        <div className="grid gap-5">
          <section className="panel">
            <h2 className="font-semibold mb-5">The right light</h2>
            <Field label="Appearance">
              <select
                value={theme || "light"}
                onChange={(e) => setTheme(e.target.value)}
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
                <option value="system">Match my device</option>
              </select>
            </Field>
          </section>
          <section className="panel">
            <h2 className="font-semibold mb-3">Your work belongs to you.</h2>
            <p className="text-sm text-muted-foreground mb-5">
              {store.owner === "guest"
                ? "Guest data stays in this browser. Export a backup or sign in to save across devices."
                : "Your account workspace syncs automatically. Guest work stays separate until you import it."}
            </p>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={store.exportData}>
                <Download />
                Export backup
              </Button>
              {store.owner === "guest" ? (
                <Button onClick={onLogin}>
                  <UserRound />
                  Sign in
                </Button>
              ) : (
                <Button
                  variant="outline"
                  onClick={() => {
                    try {
                      const text = localStorage.getItem(GUEST_KEY);
                      if (!text)
                        throw new Error(
                          "No guest workspace was found on this device.",
                        );
                      importData(text);
                    } catch (error) {
                      setError(
                        error instanceof Error
                          ? error.message
                          : "Import failed.",
                      );
                    }
                  }}
                >
                  Import guest work
                </Button>
              )}
            </div>
            <label className="grid gap-2 text-sm font-medium mt-5">
              Restore from a backup
              <input
                type="file"
                accept="application/json,.json"
                onChange={(e) => {
                  void importFile(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
            </label>
          </section>
        </div>
      </div>
      <section className="panel">
        <h2 className="font-semibold mb-4">A few useful shortcuts</h2>
        <div className="shortcut-list">
          <p>
            Find your way around <kbd>Ctrl / ⌘ K</kbd>
          </p>
          <p>
            Jump to a study tool <kbd>Alt 1–7</kbd>
          </p>
          <p>
            Send a tutor message <kbd>Enter</kbd>
          </p>
          <p>
            Add a new line <kbd>Shift Enter</kbd>
          </p>
        </div>
      </section>
      <section className="panel">
        <h2 className="font-semibold mb-3">A note on your data</h2>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Uploaded files are processed into text on the server; the original
          file is not retained. AI requests send the selected study material and
          recent conversation to the configured AI provider. AI responses may
          contain mistakes. Short answers are checked against known
          alternatives, not graded by a human. Avoid uploading private
          information you do not want processed.
        </p>
      </section>
    </div>
  );
}
