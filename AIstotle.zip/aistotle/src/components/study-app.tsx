"use client";
import { useEffect, useState } from "react";
import { useSession, signOut } from "next-auth/react";
import { useTheme } from "next-themes";
import {
  LayoutDashboard,
  MessageCircle,
  BookOpen,
  Layers,
  ClipboardCheck,
  CalendarDays,
  Timer,
  Settings as SettingsIcon,
  Search,
  Moon,
  Sun,
  Menu,
  ArrowUpRight,
  ChevronDown,
  LogOut,
  Cloud,
  HardDrive,
  Loader2,
} from "lucide-react";
import { useWorkspace } from "@/hooks/use-workspace";
import { api } from "@/lib/utils";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Notice, Spinner } from "./ui/shared";
import { AuthDialog } from "./auth-dialog";
import { Onboarding } from "./onboarding";
import { Dashboard, type View } from "./dashboard";
import { AddMaterial, Materials } from "./materials";
import { Tutor } from "./tutor";
import { Flashcards } from "./flashcards";
import { Quizzes } from "./quizzes";
import { StudyPlan } from "./study-plan";
import { Focus } from "./focus";
import { Settings } from "./settings";
const links: { id: View; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Overview", icon: LayoutDashboard },
  { id: "tutor", label: "AI tutor", icon: MessageCircle },
  { id: "materials", label: "My materials", icon: BookOpen },
  { id: "flashcards", label: "Flashcards", icon: Layers },
  { id: "quizzes", label: "Quizzes", icon: ClipboardCheck },
  { id: "plan", label: "Study plan", icon: CalendarDays },
  { id: "focus", label: "Focus timer", icon: Timer },
];
export function StudyApp() {
  const store = useWorkspace(),
    { data: session } = useSession(),
    { resolvedTheme, setTheme } = useTheme();
  const [view, setView] = useState<View>("dashboard"),
    [selected, setSelected] = useState(""),
    [add, setAdd] = useState(false),
    [login, setLogin] = useState(false),
    [mobile, setMobile] = useState(false),
    [command, setCommand] = useState(false),
    [query, setQuery] = useState(""),
    [onboarding, setOnboarding] = useState(false),
    [config, setConfig] = useState<{
      aiConfigured: boolean;
      googleConfigured: boolean;
      guestAI: boolean;
    } | null>(null),
    [configError, setConfigError] = useState(""),
    [accountError, setAccountError] = useState("");
  function navigate(next: View) {
    setView(next);
    setMobile(false);
    setCommand(false);
    window.scrollTo({ top: 0, behavior: "instant" });
  }
  useEffect(() => {
    void api<{
      aiConfigured: boolean;
      googleConfigured: boolean;
      guestAI: boolean;
    }>("/api/config")
      .then(setConfig)
      .catch(() =>
        setConfigError(
          "Service configuration could not be loaded. Refresh the page to retry.",
        ),
      );
    const params = new URLSearchParams(window.location.search);
    if (params.has("error")) {
      setAccountError(
        "Sign-in did not finish. If this email already uses a password, sign in with that password.",
      );
      setLogin(true);
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, []);
  useEffect(() => {
    if (store.loaded) setOnboarding(!store.data.profile.onboarded);
  }, [store.loaded, store.owner]);
  useEffect(() => {
    setSelected("");
    setView("dashboard");
  }, [store.owner]);
  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommand((v) => !v);
      }
      if (
        event.altKey &&
        /^[1-7]$/.test(event.key) &&
        !(event.target instanceof HTMLInputElement) &&
        !(event.target instanceof HTMLTextAreaElement)
      ) {
        event.preventDefault();
        navigate(links[Number(event.key) - 1].id);
      }
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  }, []);
  const due = store.data.cards.filter(
    (c) => new Date(c.due) <= new Date(),
  ).length;
  async function logout() {
    setAccountError("");
    const synced = await store.flush();
    if (!synced) {
      setAccountError("Export your unsaved work before signing out.");
      return;
    }
    await signOut({ callbackUrl: "/" });
  }
  const navigation = (
    <>
      <a
        className="brand"
        href="/"
        onClick={(event) => {
          event.preventDefault();
          navigate("dashboard");
        }}
        aria-label="AIstotle home"
      >
        <span className="brand-mark">
          a<span>✳</span>
        </span>
        <span>
          AIstotle<span className="brand-period">.</span>
        </span>
      </a>
      <div className="workspace-badge">
        <span className="workspace-avatar">
          {(session?.user.name || "My")[0].toUpperCase()}
        </span>
        <span>
          <strong>My study space</strong>
          <small>{session ? "Personal account" : "Personal · Guest"}</small>
        </span>
        <ChevronDown size={14} />
      </div>
      <p className="nav-section-label">YOUR LEARNING</p>
      <nav aria-label="Main navigation">
        {links.map((link, index) => (
          <button
            className={`nav-link ${view === link.id ? "active" : ""}`}
            key={link.id}
            aria-current={view === link.id ? "page" : undefined}
            onClick={() => navigate(link.id)}
            title={`Alt + ${index + 1}`}
          >
            <link.icon size={19} />
            <span>{link.label}</span>
            {link.id === "tutor" && <span className="ai-badge">AI</span>}
            {link.id === "flashcards" && due > 0 && (
              <span className="count-badge">{due}</span>
            )}
          </button>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <div className="curiosity-note">
          <span>✳</span>
          <p>
            Great things begin
            <br />
            with a little curiosity.
          </p>
          <small>Make today a learning day.</small>
        </div>
        {!session && (
          <button
            className="sidebar-signin"
            onClick={() => {
              setMobile(false);
              setLogin(true);
            }}
          >
            Save your progress <ArrowUpRight size={16} />
          </button>
        )}
        <button
          className={`nav-link ${view === "settings" ? "active" : ""}`}
          onClick={() => navigate("settings")}
        >
          <SettingsIcon size={18} />
          <span>Settings</span>
        </button>
        {session && (
          <button
            className="nav-link"
            onClick={() => void logout()}
            disabled={store.saving}
          >
            <LogOut size={18} />
            <span>Sign out</span>
          </button>
        )}
        <div className="sidebar-footer">
          <span className="online-dot" /> A quieter kind of learning.
        </div>
      </div>
    </>
  );
  return (
    <>
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <div className="app-shell">
        <aside className="sidebar">{navigation}</aside>
        <div className="main-shell">
          <header className="topbar">
            <div className="topbar-left">
              <Button
                variant="ghost"
                size="icon"
                className="mobile-menu"
                aria-label="Open navigation"
                onClick={() => setMobile(true)}
              >
                <Menu />
              </Button>
              <span className="breadcrumb">
                My workspace <span>/</span>
                <strong>
                  {view === "settings"
                    ? "Settings"
                    : links.find((l) => l.id === view)?.label}
                </strong>
              </span>
            </div>
            <div className="topbar-actions">
              <span className="save-state" role="status">
                {store.saving ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : store.owner === "guest" ? (
                  <HardDrive size={14} />
                ) : (
                  <Cloud size={14} />
                )}
                <span>
                  {store.saving
                    ? "Saving…"
                    : store.error
                      ? "Not saved"
                      : store.owner === "guest"
                        ? "On this device"
                        : "Synced"}
                </span>
              </span>
              <button
                className="search-trigger"
                onClick={() => setCommand(true)}
                aria-label="Search navigation"
              >
                <Search size={16} />
                <span>Quick find</span>
                <kbd>⌘ K</kbd>
              </button>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Toggle light and dark theme"
                onClick={() =>
                  setTheme(resolvedTheme === "dark" ? "light" : "dark")
                }
              >
                {resolvedTheme === "dark" ? <Sun /> : <Moon />}
              </Button>
              <button
                className="profile-avatar"
                onClick={() =>
                  session ? navigate("settings") : setLogin(true)
                }
                aria-label={session ? "Open account settings" : "Sign in"}
              >
                {(session?.user.name || "Guest").slice(0, 1).toUpperCase()}
              </button>
            </div>
          </header>
          <main id="main-content" tabIndex={-1} className="main-content">
            {store.error && (
              <Notice>
                {store.error}{" "}
                <span className="inline-flex gap-3 ml-2">
                  <button className="underline" onClick={store.exportData}>
                    Export work
                  </button>
                  <button
                    className="underline"
                    onClick={() =>
                      store.loaded ? void store.flush() : store.reload()
                    }
                  >
                    Retry
                  </button>
                </span>
              </Notice>
            )}
            {accountError && <Notice>{accountError}</Notice>}
            {configError && <Notice>{configError}</Notice>}
            {!store.loaded ? (
              <Spinner
                label={
                  store.error
                    ? "Your workspace is unavailable. Use Retry above."
                    : "Opening your study space…"
                }
              />
            ) : (
              <>
                {view === "dashboard" && (
                  <Dashboard
                    store={store}
                    name={session?.user.name}
                    navigate={navigate}
                    addMaterial={() => setAdd(true)}
                    chooseMaterial={setSelected}
                  />
                )}
                <div hidden={view !== "tutor"}>
                  {view === "tutor" && (
                    <Tutor
                      store={store}
                      selected={selected}
                      onSelect={setSelected}
                    />
                  )}
                </div>
                {view === "materials" && (
                  <Materials
                    store={store}
                    selected={selected}
                    onSelect={setSelected}
                    onAdd={() => setAdd(true)}
                    onTutor={() => navigate("tutor")}
                  />
                )}{" "}
                {view === "flashcards" && (
                  <Flashcards
                    store={store}
                    selected={selected}
                    onSelect={setSelected}
                  />
                )}{" "}
                {view === "quizzes" && (
                  <Quizzes
                    store={store}
                    selected={selected}
                    onSelect={setSelected}
                  />
                )}{" "}
                {view === "plan" && <StudyPlan store={store} />}
                <Focus
                  key={store.owner}
                  store={store}
                  active={view === "focus"}
                />
                {view === "settings" && (
                  <Settings store={store} onLogin={() => setLogin(true)} />
                )}
              </>
            )}
          </main>
        </div>
      </div>
      <Dialog open={mobile} onOpenChange={setMobile}>
        <DialogContent className="mobile-navigation">
          <DialogTitle className="sr-only">Navigation</DialogTitle>
          <DialogDescription className="sr-only">
            Choose a learning tool.
          </DialogDescription>
          {navigation}
        </DialogContent>
      </Dialog>
      <Dialog open={command} onOpenChange={setCommand}>
        <DialogContent>
          <DialogTitle className="text-xl font-semibold">
            Where will curiosity take you?
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground mt-2 mb-5">
            Jump to your next study tool.
          </DialogDescription>
          <input
            aria-label="Find a tool"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Find a tool…"
            autoFocus
          />
          <div className="command-results">
            {[
              ...links,
              { id: "settings" as View, label: "Settings", icon: SettingsIcon },
            ]
              .filter((l) =>
                l.label.toLowerCase().includes(query.toLowerCase()),
              )
              .map((link) => (
                <button key={link.id} onClick={() => navigate(link.id)}>
                  <link.icon size={18} />
                  {link.label}
                  <ArrowUpRight size={16} />
                </button>
              ))}
            {![...links, { label: "Settings" }].some((l) =>
              l.label.toLowerCase().includes(query.toLowerCase()),
            ) && (
              <p className="text-sm text-muted-foreground p-4">
                No matching tools. Try “quiz” or “focus”.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
      <AuthDialog
        open={login}
        onOpenChange={setLogin}
        google={config?.googleConfigured || false}
      />
      {store.loaded && (
        <>
          <AddMaterial
            store={store}
            open={add}
            onOpenChange={setAdd}
            onAdded={(id) => {
              setSelected(id);
              navigate("materials");
            }}
          />
          <Onboarding
            store={store}
            open={onboarding}
            onOpenChange={setOnboarding}
          />
        </>
      )}
    </>
  );
}
