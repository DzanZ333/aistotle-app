"use client";
import { useState } from "react";
import { CalendarDays, Check, ArrowUpRight } from "lucide-react";
import type { StudyStore } from "@/hooks/use-workspace";
import { createPlan, localDay } from "@/lib/study";
import { Button } from "./ui/button";
import { Empty, Field, Notice, Progress, SectionTitle } from "./ui/shared";
export function StudyPlan({ store }: { store: StudyStore }) {
  const [exam, setExam] = useState(""),
    [hours, setHours] = useState("1"),
    [error, setError] = useState("");
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const max = new Date();
  max.setDate(max.getDate() + 365);
  function generate(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    try {
      const tasks = createPlan(
        exam,
        Number(hours),
        store.data.materials.length
          ? store.data.materials.map((m) => m.title)
          : [store.data.profile.subject],
      );
      if (
        store.data.tasks.length &&
        !window.confirm(
          "Replace the current study plan and its task checkmarks?",
        )
      )
        return;
      store.update((prev) => ({ ...prev, tasks }), true);
    } catch (error) {
      setError(
        error instanceof Error ? error.message : "Could not create a plan.",
      );
    }
  }
  const dates = [...new Set(store.data.tasks.map((t) => t.date))].sort();
  const done = store.data.tasks.filter((t) => t.done).length;
  return (
    <div className="page-stack">
      <SectionTitle
        eyebrow="A LITTLE DIRECTION GOES A LONG WAY"
        title="Make space for progress."
        description="A realistic daily plan, built around your time and your exam."
      />
      <section className="panel">
        <form className="plan-form" onSubmit={generate}>
          <Field label="When is your exam?">
            <input
              type="date"
              value={exam}
              onChange={(e) => setExam(e.target.value)}
              min={localDay(tomorrow)}
              max={localDay(max)}
              required
            />
          </Field>
          <Field label="Study hours per day">
            <input
              type="number"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
              min="0.25"
              max="8"
              step="0.25"
              required
            />
          </Field>
          <Button type="submit" size="lg">
            {dates.length ? "Rebuild my plan" : "Build my plan"}
            <ArrowUpRight />
          </Button>
        </form>
        <p className="text-xs text-muted-foreground mt-4">
          Your materials rotate daily, with 25% of your time reserved for
          recall. The final two days prioritize practice. Study runs up to the
          day before your exam.
        </p>
        {error && (
          <div className="mt-4">
            <Notice>{error}</Notice>
          </div>
        )}
      </section>
      {dates.length ? (
        <>
          <section className="panel">
            <div className="panel-heading">
              <h2>One step at a time.</h2>
              <span className="chip">
                {done} / {store.data.tasks.length} tasks complete
              </span>
            </div>
            <Progress
              value={(done / store.data.tasks.length) * 100}
              label="Study plan completion"
            />
          </section>
          <div className="plan-days">
            {dates.map((date) => (
              <section
                className={`panel plan-day ${date === localDay() ? "today" : ""}`}
                key={date}
              >
                <div className="plan-date">
                  <span className="eyebrow">
                    {date === localDay()
                      ? "TODAY"
                      : new Date(`${date}T12:00:00`).toLocaleDateString("en", {
                          weekday: "long",
                        })}
                  </span>
                  <h2>
                    {new Date(`${date}T12:00:00`).toLocaleDateString("en", {
                      month: "short",
                      day: "numeric",
                    })}
                  </h2>
                  <p>
                    {store.data.tasks
                      .filter((t) => t.date === date)
                      .reduce((sum, t) => sum + t.minutes, 0)}{" "}
                    minutes
                  </p>
                </div>
                <div className="task-list">
                  {store.data.tasks
                    .filter((t) => t.date === date)
                    .map((task) => (
                      <label key={task.id} className="task-row">
                        <input
                          type="checkbox"
                          checked={task.done}
                          onChange={() =>
                            store.update(
                              (prev) => ({
                                ...prev,
                                tasks: prev.tasks.map((t) =>
                                  t.id === task.id
                                    ? { ...t, done: !t.done }
                                    : t,
                                ),
                              }),
                              true,
                            )
                          }
                        />
                        <span
                          className={
                            task.done
                              ? "line-through text-muted-foreground"
                              : ""
                          }
                        >
                          {task.title}
                          <small>{task.minutes} minutes</small>
                        </span>
                        {task.done && (
                          <Check size={17} className="text-accent-strong" />
                        )}
                      </label>
                    ))}
                </div>
              </section>
            ))}
          </div>
        </>
      ) : (
        <div className="panel">
          <Empty
            icon={CalendarDays}
            title="A big goal. Smaller steps."
            description="Choose your exam date and the time you have. Your daily study tasks will appear here."
          />
        </div>
      )}
    </div>
  );
}
