"use client";
import { newId } from "@/lib/id";
import { useEffect, useRef, useState } from "react";
import {
  ArrowUp,
  Square,
  MessageCircle,
  Sparkles,
  Trash2,
  RotateCcw,
} from "lucide-react";
import type { StudyStore } from "@/hooks/use-workspace";
import type { Message } from "@/lib/schema";
import { sseData } from "@/lib/sse";
import { Button } from "./ui/button";
import { Notice, SectionTitle } from "./ui/shared";
import { MaterialSelect } from "./materials";
import { Markdown } from "./markdown";
export function Tutor({
  store,
  selected,
  onSelect,
}: {
  store: StudyStore;
  selected: string;
  onSelect: (id: string) => void;
}) {
  const [input, setInput] = useState(""),
    [stream, setStream] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [retry, setRetry] = useState("");
  const abort = useRef<AbortController | null>(null),
    end = useRef<HTMLDivElement>(null),
    mounted = useRef(true),
    lock = useRef(false);
  const material = store.data.materials.find((m) => m.id === selected);
  const materialId = material?.id || "subject";
  const messages = store.data.messages.filter(
    (m) => (m.materialId || "subject") === materialId,
  );
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      abort.current?.abort();
    };
  }, []);
  useEffect(() => {
    end.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [stream, messages.length]);
  async function send(text: string, retrying = false) {
    if (!text.trim() || lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setStream("");
    setRetry(text);
    const controller = new AbortController();
    abort.current = controller;
    let answer = "";
    let complete = false;
    const question: Message = {
      id: newId(),
      role: "user",
      content: text.trim(),
      createdAt: new Date().toISOString(),
      materialId,
    };
    const history =
      retrying && messages.at(-1)?.role === "user"
        ? messages
        : [...messages, question];
    if (
      history !== messages &&
      !store.update(
        (prev) => ({
          ...prev,
          messages: [...prev.messages, question].slice(-300),
        }),
        true,
      )
    ) {
      lock.current = false;
      setBusy(false);
      return;
    }
    setInput("");
    try {
      const response = await fetch("/api/ai", {
        method: "POST",
        signal: controller.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "chat",
          title: material?.title || store.data.profile.subject,
          material: material?.text || store.data.profile.subject,
          level: store.data.profile.level,
          goal: store.data.profile.goal,
          messages: history
            .slice(-16)
            .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) })),
        }),
      });
      if (!response.ok) {
        const body = await response.json();
        throw new Error(body.error || "The tutor could not respond.");
      }
      if (!response.body)
        throw new Error("No response received. Please retry.");
      for await (const raw of sseData(response.body)) {
        const event = JSON.parse(raw);
        if (event.error) throw new Error(event.error);
        if (event.token) {
          answer += event.token;
          if (mounted.current) setStream(answer);
        }
        if (event.done) complete = true;
      }
      if (!complete)
        throw new Error(
          "The connection ended before the answer was complete. Please retry.",
        );
      store.update(
        (prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: newId(),
              role: "assistant",
              content: answer.slice(0, 16000),
              createdAt: new Date().toISOString(),
              materialId,
            } as Message,
          ].slice(-300),
        }),
        true,
      );
      if (mounted.current) {
        setStream("");
        setRetry("");
      }
    } catch (error) {
      if (mounted.current) {
        setError(
          controller.signal.aborted
            ? "Response stopped. You can retry when you’re ready."
            : error instanceof Error
              ? error.message
              : "The tutor is unavailable. Please retry.",
        );
        setStream("");
      }
    } finally {
      lock.current = false;
      if (mounted.current) setBusy(false);
    }
  }
  return (
    <div className="page-stack tutor-page">
      <SectionTitle
        eyebrow="A GOOD QUESTION CHANGES EVERYTHING"
        title="Let’s think it through."
        description="Your patient partner for the parts that haven’t clicked. Yet."
      />
      <div className="toolbar">
        <MaterialSelect
          store={store}
          value={selected}
          onChange={(id) => {
            if (!busy) {
              onSelect(id);
              setError("");
              setRetry("");
            }
          }}
        />
        <div className="flex items-center gap-2">
          <span className="chip capitalize">{store.data.profile.level}</span>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Clear this conversation"
            disabled={busy || !messages.length}
            onClick={() => {
              if (window.confirm("Clear this conversation?"))
                store.update((prev) => ({
                  ...prev,
                  messages: prev.messages.filter(
                    (m) => (m.materialId || "subject") !== materialId,
                  ),
                }));
            }}
          >
            <Trash2 />
          </Button>
        </div>
      </div>
      <section className="chat-panel">
        <div
          className="chat-messages"
          aria-label="Conversation"
          aria-busy={busy}
        >
          {!messages.length && !busy ? (
            <div className="tutor-welcome">
              <span className="tutor-emblem">
                a<span>✳</span>
              </span>
              <h2>Start with what makes you wonder.</h2>
              <p>We’ll connect the dots together. No question is too small.</p>
              <div className="prompt-grid">
                {[
                  `Help me understand ${material?.title || store.data.profile.subject}`,
                  `Ask me a question to check my understanding`,
                  `Explain the basics with a real-world example`,
                  `What are the most common misconceptions?`,
                ].map((prompt, i) => (
                  <button key={prompt} onClick={() => void send(prompt)}>
                    <Sparkles size={16} />
                    <span>{prompt}</span>
                    <ArrowUp size={15} />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <article
                  key={message.id}
                  className={`chat-message ${message.role}`}
                >
                  <span
                    className="chat-avatar"
                    aria-label={message.role === "user" ? "You" : "AIstotle"}
                  >
                    {message.role === "user" ? "Y" : "a✳"}
                  </span>
                  <div>
                    <p className="message-label">
                      {message.role === "user" ? "You" : "AIstotle"}
                    </p>
                    <Markdown>{message.content}</Markdown>
                  </div>
                </article>
              ))}
              {busy && (
                <article className="chat-message assistant">
                  <span className="chat-avatar">a✳</span>
                  <div>
                    <p className="message-label">AIstotle</p>
                    {stream ? (
                      <Markdown>{stream}</Markdown>
                    ) : (
                      <p className="text-muted-foreground" role="status">
                        Thinking it through
                        <span className="thinking-dots">…</span>
                      </p>
                    )}
                  </div>
                </article>
              )}
            </>
          )}
          <div ref={end} />
        </div>
        {error && (
          <div className="px-5 pb-2">
            <Notice>
              {error}
              {retry && (
                <button
                  className="inline-flex items-center gap-1 underline ml-2"
                  onClick={() => void send(retry, true)}
                  disabled={busy}
                >
                  <RotateCcw size={14} />
                  Retry
                </button>
              )}
            </Notice>
          </div>
        )}
        <div className="chat-compose">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void send(input);
            }}
          >
            <textarea
              aria-label="Your question"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              maxLength={8000}
              rows={2}
              placeholder="Ask a question. Follow a thought. Find your aha."
              disabled={busy}
              onKeyDown={(e) => {
                if (
                  e.key === "Enter" &&
                  !e.shiftKey &&
                  !e.nativeEvent.isComposing
                ) {
                  e.preventDefault();
                  void send(input);
                }
              }}
            />
            {busy ? (
              <Button
                size="icon"
                type="button"
                aria-label="Stop response"
                onClick={() => abort.current?.abort()}
              >
                <Square />
              </Button>
            ) : (
              <Button
                size="icon"
                type="submit"
                aria-label="Send question"
                disabled={!input.trim()}
              >
                <ArrowUp />
              </Button>
            )}
          </form>
          <p>
            Enter to send · Shift + Enter for a new line · AI can make mistakes.
            Check important facts.
          </p>
        </div>
      </section>
    </div>
  );
}
