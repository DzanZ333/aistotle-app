"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useSession } from "next-auth/react";
import { emptyWorkspace, workspaceSchema, type Workspace } from "@/lib/schema";
import { markActivity } from "@/lib/study";
import { api } from "@/lib/utils";
export const GUEST_KEY = "aistotle:guest:v1";
export function useWorkspace() {
  const { data: session, status } = useSession();
  const owner = session?.user.id || "guest";
  const [data, setData] = useState<Workspace>(emptyWorkspace);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [reload, setReload] = useState(0);
  const current = useRef(data),
    revision = useRef(0),
    saved = useRef(""),
    identity = useRef(""),
    busy = useRef(false),
    abort = useRef<AbortController | null>(null);
  useEffect(() => {
    if (status === "loading") return;
    let cancelled = false;
    abort.current?.abort();
    busy.current = false;
    setSaving(false);
    identity.current = owner;
    setLoaded(false);
    setError("");
    (async () => {
      try {
        let next: Workspace;
        if (owner === "guest") {
          const raw = localStorage.getItem(GUEST_KEY);
          next = raw
            ? workspaceSchema.parse(JSON.parse(raw))
            : emptyWorkspace();
          revision.current = 0;
        } else {
          const result = await api<{ data: Workspace; revision: number }>(
            "/api/workspace",
          );
          next = workspaceSchema.parse(result.data);
          revision.current = result.revision;
        }
        if (cancelled) return;
        current.current = next;
        saved.current = JSON.stringify(next);
        setData(next);
        setLoaded(true);
      } catch (error) {
        if (!cancelled)
          setError(
            error instanceof Error
              ? error.message
              : "Your study space could not be loaded.",
          );
      }
    })();
    return () => {
      cancelled = true;
      abort.current?.abort();
    };
  }, [owner, status, reload]);
  const flush = useCallback(async () => {
    if (!loaded || busy.current || identity.current !== owner) return false;
    busy.current = true;
    setSaving(true);
    setError("");
    const controller = new AbortController();
    abort.current = controller;
    try {
      while (identity.current === owner) {
        const snapshot = JSON.stringify(current.current);
        if (snapshot === saved.current) break;
        if (owner === "guest") {
          const existing = localStorage.getItem(GUEST_KEY);
          if (existing && existing !== saved.current)
            throw new Error(
              "Your guest workspace changed in another tab. Export your changes, then reload.",
            );
          localStorage.setItem(GUEST_KEY, snapshot);
        } else {
          const result = await api<{ revision: number }>("/api/workspace", {
            method: "PUT",
            signal: controller.signal,
            body: JSON.stringify({
              data: JSON.parse(snapshot),
              revision: revision.current,
            }),
          });
          revision.current = result.revision;
        }
        saved.current = snapshot;
      }
      return true;
    } catch (error) {
      if (!controller.signal.aborted)
        setError(
          error instanceof Error
            ? error.message
            : "Your changes could not be saved. Export your work before closing this page.",
        );
      return false;
    } finally {
      if (identity.current === owner) {
        busy.current = false;
        setSaving(false);
      }
    }
  }, [owner, loaded]);
  useEffect(() => {
    if (!loaded) return;
    const timer = setTimeout(() => {
      void flush();
    }, 500);
    return () => clearTimeout(timer);
  }, [data, loaded, flush]);
  useEffect(() => {
    const beforeUnload = (event: BeforeUnloadEvent) => {
      if (JSON.stringify(current.current) !== saved.current) {
        event.preventDefault();
      }
    };
    window.addEventListener("beforeunload", beforeUnload);
    return () => window.removeEventListener("beforeunload", beforeUnload);
  }, []);
  const update = useCallback(
    (change: (prev: Workspace) => Workspace, activity = false) => {
      let next = change(current.current);
      if (activity) next = markActivity(next);
      const parsed = workspaceSchema.safeParse(next);
      if (
        !parsed.success ||
        new TextEncoder().encode(JSON.stringify(parsed.data)).length > 3_900_000
      ) {
        setError(
          "This action exceeds the workspace limits. Export or remove older items before continuing.",
        );
        return false;
      }
      current.current = parsed.data;
      setData(parsed.data);
      return true;
    },
    [],
  );
  const exportData = useCallback(() => {
    const blob = new Blob([JSON.stringify(current.current, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "aistotle-study-backup.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }, []);
  return {
    data,
    update,
    loaded,
    error,
    saving,
    owner,
    flush,
    exportData,
    reload: () => setReload((v) => v + 1),
  };
}
export type StudyStore = ReturnType<typeof useWorkspace>;
