import { HttpError } from "./security";
import { sseData } from "./sse";
type Turn = { role: "user" | "assistant"; content: string };
const sleep = (ms: number, signal: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    if (signal.aborted) return reject(signal.reason);
    const abort = () => {
      clearTimeout(timer);
      reject(signal.reason);
    };
    const timer = setTimeout(() => {
      signal.removeEventListener("abort", abort);
      resolve();
    }, ms);
    signal.addEventListener("abort", abort, { once: true });
  });
export async function* completion(
  system: string,
  messages: Turn[],
  signal: AbortSignal,
): AsyncGenerator<string> {
  const key = process.env.AI_API_KEY,
    model = process.env.AI_MODEL;
  if (!key || !model)
    throw new HttpError(
      503,
      "AI is not connected yet. Add your AI API key and model to the server environment. Your study tools and saved work are still available.",
    );
  const provider = process.env.AI_PROVIDER || "openai-compatible";
  if (!["anthropic", "openai-compatible"].includes(provider))
    throw new HttpError(503, "The configured AI provider is not supported.");
  const anthropic = provider === "anthropic";
  const base = (
    process.env.AI_BASE_URL ||
    (anthropic ? "https://api.anthropic.com/v1" : "https://api.openai.com/v1")
  ).replace(/\/$/, "");
  const url = new URL(`${base}/${anthropic ? "messages" : "chat/completions"}`);
  if (
    url.protocol !== "https:" &&
    !["localhost", "127.0.0.1"].includes(url.hostname)
  )
    throw new HttpError(503, "The AI endpoint must use HTTPS.");
  const timeout = AbortSignal.any([signal, AbortSignal.timeout(90000)]);
  let response: Response | undefined;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      response = await fetch(url, {
        method: "POST",
        signal: timeout,
        headers: {
          "Content-Type": "application/json",
          ...(anthropic
            ? { "x-api-key": key, "anthropic-version": "2023-06-01" }
            : { Authorization: `Bearer ${key}` }),
        },
        body: JSON.stringify(
          anthropic
            ? { model, system, messages, stream: true, max_tokens: 5000 }
            : {
                model,
                messages: [{ role: "system", content: system }, ...messages],
                stream: true,
                max_tokens: 5000,
              },
        ),
      });
    } catch (error) {
      if (timeout.aborted)
        throw new HttpError(
          504,
          "The AI request timed out or was cancelled. Please retry.",
        );
      if (attempt === 2)
        throw new HttpError(
          502,
          "Could not reach the AI service. Please retry.",
        );
      await sleep(600 * 2 ** attempt, timeout);
      continue;
    }
    if (response.ok) break;
    if (![429, 500, 502, 503, 504].includes(response.status) || attempt === 2) {
      await response.body?.cancel();
      throw new HttpError(
        502,
        "The AI service is temporarily unavailable. Check the configured model and credentials, then retry.",
      );
    }
    await response.body?.cancel();
    await sleep(600 * 2 ** attempt + Math.random() * 200, timeout);
  }
  if (!response?.body)
    throw new HttpError(502, "The AI service returned no response.");
  let length = 0;
  for await (const raw of sseData(response.body)) {
    if (raw === "[DONE]") break;
    let event;
    try {
      event = JSON.parse(raw);
    } catch {
      throw new HttpError(
        502,
        "The AI service returned an invalid stream. Please retry.",
      );
    }
    if (event.error || event.type === "error")
      throw new HttpError(
        502,
        "The AI service interrupted the response. Please retry.",
      );
    const chunk = anthropic
      ? event.type === "content_block_delta"
        ? event.delta?.text
        : ""
      : event.choices?.[0]?.delta?.content;
    if (typeof chunk === "string") {
      length += chunk.length;
      if (length > 50000)
        throw new HttpError(
          502,
          "The AI response was too long. Try a smaller request.",
        );
      yield chunk;
    }
  }
  if (!length)
    throw new HttpError(
      502,
      "The AI service returned an empty answer. Please retry.",
    );
}
