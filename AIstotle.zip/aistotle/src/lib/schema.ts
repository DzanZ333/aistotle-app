import { z } from "zod";
const id = z.string().min(1).max(100);
const date = z.iso.datetime();
export const levelSchema = z.enum(["beginner", "intermediate", "advanced"]);
export const profileSchema = z.object({
  subject: z.string().min(1).max(100),
  level: levelSchema,
  goal: z.string().min(1).max(300),
  onboarded: z.boolean(),
});
export const summarySchema = z.object({
  summary: z.string().min(1).max(6000),
  concepts: z.array(z.string().max(500)).min(1).max(12),
  glossary: z
    .array(
      z.object({ term: z.string().max(150), definition: z.string().max(1000) }),
    )
    .max(15),
});
export const materialSchema = z.object({
  id,
  title: z.string().min(1).max(150),
  text: z.string().min(1).max(60000),
  kind: z.enum(["text", "topic", "file"]),
  createdAt: date,
  summary: summarySchema.optional(),
});
export const cardSchema = z.object({
  id,
  materialId: id,
  front: z.string().min(1).max(1000),
  back: z.string().min(1).max(3000),
  ease: z.number().min(1.3).max(5),
  interval: z.number().int().min(0).max(36500),
  repetitions: z.number().int().min(0).max(10000),
  due: date,
  lastReviewed: date.optional(),
});
export const questionSchema = z
  .object({
    id,
    type: z.enum(["multiple-choice", "true-false", "short-answer"]),
    prompt: z.string().min(1).max(2000),
    options: z.array(z.string().min(1).max(500)).max(6),
    answer: z.string().min(1).max(1000),
    acceptedAnswers: z.array(z.string().min(1).max(1000)).max(10),
    explanation: z.string().min(1).max(2500),
    topic: z.string().min(1).max(100),
  })
  .superRefine((q, ctx) => {
    if (
      q.type === "multiple-choice" &&
      (q.options.length !== 4 ||
        !q.options.includes(q.answer) ||
        new Set(q.options).size !== 4)
    )
      ctx.addIssue({
        code: "custom",
        message:
          "Multiple choice needs four unique options and a matching answer",
      });
    if (
      q.type === "true-false" &&
      (!["True", "False"].includes(q.answer) ||
        q.options.join("|") !== "True|False")
    )
      ctx.addIssue({
        code: "custom",
        message: "True/false needs True and False options",
      });
    if (q.type === "short-answer" && q.options.length)
      ctx.addIssue({
        code: "custom",
        message: "Short answers cannot have options",
      });
  });
export const quizSchema = z.object({
  id,
  materialId: id,
  title: z.string().max(150),
  createdAt: date,
  questions: z.array(questionSchema).min(1).max(20),
});
export const attemptSchema = z.object({
  id,
  quizId: id,
  createdAt: date,
  correct: z.number().int().min(0).max(20),
  total: z.number().int().min(1).max(20),
  answers: z.record(z.string(), z.string().max(3000)),
  topics: z
    .array(z.object({ topic: z.string().max(100), correct: z.boolean() }))
    .max(20),
});
export const taskSchema = z.object({
  id,
  date: z.iso.date(),
  title: z.string().max(300),
  minutes: z.number().int().min(1).max(480),
  done: z.boolean(),
});
export const focusSchema = z.object({
  id,
  createdAt: date,
  minutes: z.number().int().min(1).max(120),
  subject: z.string().max(150),
});
export const messageSchema = z.object({
  id,
  role: z.enum(["user", "assistant"]),
  content: z.string().min(1).max(16000),
  createdAt: date,
  materialId: id.optional(),
});
export const workspaceSchema = z.object({
  version: z.literal(1),
  profile: profileSchema,
  materials: z.array(materialSchema).max(30),
  cards: z.array(cardSchema).max(1000),
  quizzes: z.array(quizSchema).max(100),
  attempts: z.array(attemptSchema).max(500),
  tasks: z.array(taskSchema).max(1500),
  focus: z.array(focusSchema).max(3000),
  messages: z.array(messageSchema).max(300),
  activity: z.array(z.iso.date()).max(3660),
});
export type Workspace = z.infer<typeof workspaceSchema>;
export type Material = z.infer<typeof materialSchema>;
export type Card = z.infer<typeof cardSchema>;
export type Question = z.infer<typeof questionSchema>;
export type Quiz = z.infer<typeof quizSchema>;
export type Message = z.infer<typeof messageSchema>;
export function emptyWorkspace(): Workspace {
  return {
    version: 1,
    profile: {
      subject: "General learning",
      level: "beginner",
      goal: "Build lasting understanding",
      onboarded: false,
    },
    materials: [],
    cards: [],
    quizzes: [],
    attempts: [],
    tasks: [],
    focus: [],
    messages: [],
    activity: [],
  };
}
