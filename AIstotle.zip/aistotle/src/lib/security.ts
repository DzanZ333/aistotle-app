import { createHash } from "node:crypto";
import { db } from "./db";
export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public retryAfter = 60,
  ) {
    super(message);
  }
}
export function checkOrigin(request: Request) {
  const origin = request.headers.get("origin");
  const expected = process.env.AUTH_URL || "http://localhost:3000";
  if (!origin || origin !== new URL(expected).origin)
    throw new HttpError(403, "Request origin is not allowed.");
}
export function clientKey(request: Request) {
  const headers = request.headers;
  const ip = process.env.VERCEL
    ? headers.get("x-vercel-forwarded-for")
    : process.env.TRUST_PROXY === "true"
      ? headers.get("x-real-ip")
      : "shared-local";
  return createHash("sha256")
    .update(ip?.split(",")[0]?.trim() || "shared-anonymous")
    .digest("hex");
}
export async function rateLimit(key: string, limit: number, seconds = 60) {
  const window = Math.floor(Date.now() / (seconds * 1000));
  const hashed = createHash("sha256").update(key).digest("hex");
  const bucket = await db.rateBucket.upsert({
    where: { key_window: { key: hashed, window } },
    create: {
      key: hashed,
      window,
      count: 1,
      expiresAt: new Date((window + 2) * seconds * 1000),
    },
    update: { count: { increment: 1 } },
  });
  // Cleanup is opportunistic and cannot affect enforcement.
  if (Math.random() < 0.01)
    await db.rateBucket
      .deleteMany({ where: { expiresAt: { lt: new Date() } } })
      .catch(() => {});
  if (bucket.count > limit)
    throw new HttpError(
      429,
      "You have reached the request limit. Please try again later.",
      Math.max(
        1,
        Math.ceil(((window + 1) * seconds * 1000 - Date.now()) / 1000),
      ),
    );
}
export async function readBytes(
  request: Request,
  limit: number,
): Promise<Uint8Array> {
  if (Number(request.headers.get("content-length") || 0) > limit)
    throw new HttpError(413, "This upload is too large.");
  if (!request.body) throw new HttpError(400, "A request body is required.");
  const reader = request.body.getReader();
  const parts: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > limit) {
        await reader.cancel();
        throw new HttpError(413, "This upload is too large.");
      }
      parts.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const body = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    body.set(part, offset);
    offset += part.length;
  }
  return body;
}
export async function readJson(request: Request, limit = 150000) {
  const bytes = await readBytes(request, limit);
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new HttpError(400, "Send valid JSON.");
  }
}
export function errorResponse(error: unknown) {
  if (error instanceof HttpError)
    return Response.json(
      { error: error.message },
      {
        status: error.status,
        headers:
          error.status === 429
            ? { "Retry-After": String(error.retryAfter) }
            : {},
      },
    );
  if (error instanceof Error && error.name === "ZodError")
    return Response.json(
      {
        error:
          "Some inputs are invalid or exceed the allowed size. Please check them and retry.",
      },
      { status: 400 },
    );
  // Do not log study text, credentials, or provider response bodies.
  console.error(
    "Request failed",
    error instanceof Error ? error.name : "UnknownError",
  );
  return Response.json(
    { error: "Something went wrong. Please try again." },
    { status: 500 },
  );
}
