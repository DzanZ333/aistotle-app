// Handles arbitrary network chunks, CRLF, multiline SSE data, and final EOF.
export async function* sseData(
  stream: ReadableStream<Uint8Array>,
): AsyncGenerator<string> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let data: string[] = [];
  const line = (value: string): string | undefined => {
    if (value === "") {
      if (data.length) {
        const event = data.join("\n");
        data = [];
        return event;
      }
    } else if (value.startsWith("data:"))
      data.push(value.slice(5).replace(/^ /, ""));
    return undefined;
  };
  try {
    while (true) {
      const { value, done } = await reader.read();
      buffer += done
        ? decoder.decode()
        : decoder.decode(value, { stream: true });
      if (buffer.length > 1_000_000)
        throw new Error("Stream event is too large.");
      let index;
      while ((index = buffer.indexOf("\n")) !== -1) {
        const event = line(buffer.slice(0, index).replace(/\r$/, ""));
        buffer = buffer.slice(index + 1);
        if (event !== undefined) yield event;
      }
      if (done) {
        if (buffer) {
          const event = line(buffer.replace(/\r$/, ""));
          if (event !== undefined) yield event;
        }
        const event = line("");
        if (event !== undefined) yield event;
        break;
      }
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
