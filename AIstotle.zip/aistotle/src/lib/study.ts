import { newId } from "@/lib/id";
import type { Card, Question, Workspace } from "./schema";
export function localDay(date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function reviewCard(
  card: Card,
  quality: number,
  now = new Date(),
): Card {
  if (!Number.isInteger(quality) || quality < 0 || quality > 5)
    throw new Error("Quality must be an integer from 0 to 5");
  const ease = Math.max(
    1.3,
    Math.min(
      5,
      card.ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)),
    ),
  );
  const repetitions = quality < 3 ? 0 : card.repetitions + 1;
  const interval =
    quality < 3
      ? 1
      : repetitions === 1
        ? 1
        : repetitions === 2
          ? 6
          : Math.min(36500, Math.round(card.interval * card.ease));
  const due = new Date(now);
  due.setDate(due.getDate() + interval);
  return {
    ...card,
    ease,
    interval,
    repetitions,
    due: due.toISOString(),
    lastReviewed: now.toISOString(),
  };
}
export function normalizeAnswer(value: string): string {
  return value
    .normalize("NFKC")
    .toLocaleLowerCase("en")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/[.!?]+$/, "");
}
export function scoreAnswer(question: Question, answer: string): boolean {
  const normalized = normalizeAnswer(answer);
  return (
    normalized.length > 0 &&
    [question.answer, ...question.acceptedAnswers].some(
      (a) => normalizeAnswer(a) === normalized,
    )
  );
}
export function scoreQuiz(
  questions: Question[],
  answers: Record<string, string>,
) {
  const results = questions.map((q) => ({
    topic: q.topic,
    correct: scoreAnswer(q, answers[q.id] || ""),
  }));
  return {
    correct: results.filter((r) => r.correct).length,
    total: questions.length,
    topics: results,
  };
}
export function studyStreak(activity: string[], now = new Date()): number {
  const days = new Set(activity);
  const cursor = new Date(now);
  let count = 0;
  if (!days.has(localDay(cursor))) cursor.setDate(cursor.getDate() - 1);
  while (days.has(localDay(cursor))) {
    count++;
    cursor.setDate(cursor.getDate() - 1);
  }
  return count;
}
export function createPlan(
  exam: string,
  hours: number,
  topics: string[],
  now = new Date(),
) {
  const [year, month, day] = exam.split("-").map(Number);
  const end = new Date(year, month - 1, day);
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const days = Math.round(
    (Date.UTC(year, month - 1, day) -
      Date.UTC(start.getFullYear(), start.getMonth(), start.getDate())) /
      86400000,
  );
  if (
    !Number.isFinite(days) ||
    localDay(end) !== exam ||
    days < 1 ||
    days > 365
  )
    throw new Error(
      "Choose an exam date between tomorrow and 365 days from now.",
    );
  if (!Number.isFinite(hours) || hours < 0.25 || hours > 8)
    throw new Error("Choose between 0.25 and 8 hours per day.");
  const list = topics.filter(Boolean).length
    ? topics.filter(Boolean)
    : ["Your subject"];
  const minutes = Math.round(hours * 60);
  const tasks: Workspace["tasks"] = [];
  for (let i = 0; i < days; i++) {
    const date = new Date(start);
    date.setDate(date.getDate() + i);
    const topic = list[i % list.length];
    const review = Math.max(5, Math.round(minutes * 0.25));
    tasks.push({
      id: newId(),
      date: localDay(date),
      title: `${i >= days - 2 ? "Practice quiz and recall" : "Learn and explain"}: ${topic}`,
      minutes: minutes - review,
      done: false,
    });
    tasks.push({
      id: newId(),
      date: localDay(date),
      title: "Review due flashcards and revisit mistakes",
      minutes: review,
      done: false,
    });
  }
  return tasks;
}
export function markActivity(state: Workspace): Workspace {
  const day = localDay();
  return {
    ...state,
    activity: [...new Set([...state.activity, day])].sort().slice(-3660),
  };
}
