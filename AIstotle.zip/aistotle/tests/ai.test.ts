import { describe, it, expect, vi, afterEach } from "vitest";
import { completion } from "@/lib/ai";
function response(events: unknown[]) {
  return new Response(
    events.map((event) => `data: ${JSON.stringify(event)}\n\n`).join("") +
      "data: [DONE]\n\n",
    { headers: { "Content-Type": "text/event-stream" } },
  );
}
async function collect() {
  let result = "";
  for await (const token of completion(
    "You are a tutor.",
    [{ role: "user", content: "What is ATP?" }],
    new AbortController().signal,
  ))
    result += token;
  return result;
}
function configure(provider = "openai-compatible") {
  vi.stubEnv("AI_API_KEY", "unit-test-key");
  vi.stubEnv("AI_MODEL", "unit-test-model");
  vi.stubEnv("AI_PROVIDER", provider);
  vi.stubEnv(
    "AI_BASE_URL",
    provider === "anthropic"
      ? "https://api.anthropic.com/v1"
      : "https://api.openai.com/v1",
  );
}
afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});
describe("AI provider adapters", () => {
  it("streams OpenAI-compatible text chunks in order", async () => {
    configure();
    const fetch = vi
      .fn()
      .mockResolvedValue(
        response([
          { choices: [{ delta: { content: "ATP " } }] },
          { choices: [{ delta: { content: "carries energy." } }] },
        ]),
      );
    vi.stubGlobal("fetch", fetch);
    expect(await collect()).toBe("ATP carries energy.");
    expect(fetch.mock.calls[0][0].toString()).toBe(
      "https://api.openai.com/v1/chat/completions",
    );
  });
  it("supports the Anthropic streaming format", async () => {
    configure("anthropic");
    const fetch = vi
      .fn()
      .mockResolvedValue(
        response([
          {
            type: "content_block_delta",
            delta: { text: "ATP carries energy." },
          },
        ]),
      );
    vi.stubGlobal("fetch", fetch);
    expect(await collect()).toBe("ATP carries energy.");
    const body = JSON.parse(fetch.mock.calls[0][1].body);
    expect(body.system).toBe("You are a tutor.");
    expect(body.messages[0].role).toBe("user");
  });
  it("fails clearly without an API key", async () => {
    vi.stubEnv("AI_API_KEY", "");
    await expect(collect()).rejects.toThrow("AI is not connected");
  });
  it("does not retry after text has already streamed", async () => {
    configure();
    const fetch = vi
      .fn()
      .mockResolvedValue(
        response([
          { choices: [{ delta: { content: "Partial " } }] },
          { error: { message: "provider failure" } },
        ]),
      );
    vi.stubGlobal("fetch", fetch);
    await expect(collect()).rejects.toThrow("interrupted");
    expect(fetch).toHaveBeenCalledTimes(1);
  });
  it("retries a transient failure before streaming", async () => {
    configure();
    vi.useFakeTimers();
    const fetch = vi
      .fn()
      .mockResolvedValueOnce(new Response("Busy", { status: 503 }))
      .mockResolvedValueOnce(
        response([{ choices: [{ delta: { content: "Recovered" } }] }]),
      );
    vi.stubGlobal("fetch", fetch);
    const result = collect();
    await vi.runAllTimersAsync();
    expect(await result).toBe("Recovered");
    expect(fetch).toHaveBeenCalledTimes(2);
  });
});
