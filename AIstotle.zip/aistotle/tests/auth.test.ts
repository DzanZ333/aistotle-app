import { describe, it, expect, vi, beforeAll } from "vitest";
import { NextRequest } from "next/server";
import { hash } from "bcryptjs";
const mocked = vi.hoisted(() => {
  process.env.AUTH_SECRET =
    "a-test-only-secret-that-is-not-used-for-deployment";
  process.env.AUTH_URL = "http://localhost:3000";
  process.env.AUTH_TRUST_HOST = "true";
  return { user: vi.fn(), create: vi.fn() };
});
vi.mock("@/lib/db", () => ({
  db: {
    user: { findUnique: mocked.user, create: mocked.create },
    rateBucket: {
      upsert: vi.fn().mockResolvedValue({ count: 1 }),
      deleteMany: vi.fn().mockResolvedValue({ count: 0 }),
    },
  },
}));
import { handlers } from "@/auth";
import { POST as register } from "@/app/api/auth/register/route";
const origin = "http://localhost:3000";
function cookies(response: Response) {
  return response.headers
    .getSetCookie()
    .map((cookie) => cookie.split(";")[0])
    .join("; ");
}
beforeAll(async () => {
  vi.stubEnv(
    "AUTH_SECRET",
    "a-test-only-secret-that-is-not-used-for-deployment",
  );
  vi.stubEnv("AUTH_URL", origin);
  vi.stubEnv("AUTH_TRUST_HOST", "true");
  mocked.user.mockResolvedValue({
    id: "student-123",
    email: "student@example.test",
    name: "Test Student",
    passwordHash: await hash("correct-test-password", 12),
  });
});
describe("real Auth.js credentials and session handlers", () => {
  it("signs in with credentials and returns a readable, scoped session", async () => {
    const csrf = await handlers.GET(new NextRequest(`${origin}/api/auth/csrf`));
    expect(csrf.status).toBe(200);
    const { csrfToken } = await csrf.json();
    const signed = await handlers.POST(
      new NextRequest(`${origin}/api/auth/callback/credentials`, {
        method: "POST",
        headers: {
          origin,
          cookie: cookies(csrf),
          "content-type": "application/x-www-form-urlencoded",
          "X-Auth-Return-Redirect": "1",
        },
        body: new URLSearchParams({
          email: "student@example.test",
          password: "correct-test-password",
          csrfToken,
          callbackUrl: origin,
        }),
      }),
    );
    expect((await signed.json()).url).not.toContain("error=");
    expect(cookies(signed)).toContain("authjs.session-token=");
    const session = await handlers.GET(
      new NextRequest(`${origin}/api/auth/session`, {
        headers: { cookie: cookies(signed) },
      }),
    );
    const data = await session.json();
    expect(data.user.id).toBe("student-123");
    expect(data.user.email).toBe("student@example.test");
    expect(JSON.stringify(data)).not.toContain("password");
  });
  it("rejects an incorrect password without setting a session cookie", async () => {
    const csrf = await handlers.GET(new NextRequest(`${origin}/api/auth/csrf`));
    const { csrfToken } = await csrf.json();
    const response = await handlers.POST(
      new NextRequest(`${origin}/api/auth/callback/credentials`, {
        method: "POST",
        headers: {
          origin,
          cookie: cookies(csrf),
          "content-type": "application/x-www-form-urlencoded",
          "X-Auth-Return-Redirect": "1",
        },
        body: new URLSearchParams({
          email: "student@example.test",
          password: "wrong-test-password",
          csrfToken,
          callbackUrl: origin,
        }),
      }),
    );
    expect(cookies(response)).not.toContain("authjs.session-token=");
    expect((await response.json()).url).toContain("error=CredentialsSignin");
  });
  it("registers a new account with a hash, never the raw password", async () => {
    mocked.create.mockResolvedValue({ id: "new-user" });
    const response = await register(
      new Request(`${origin}/api/auth/register`, {
        method: "POST",
        headers: { origin, "content-type": "application/json" },
        body: JSON.stringify({
          name: "New Student",
          email: "new@example.test",
          password: "a-long-test-password",
        }),
      }),
    );
    expect(response.status).toBe(201);
    const saved = mocked.create.mock.calls[0][0].data;
    expect(saved.passwordHash).toMatch(/^\$2[aby]\$/);
    expect(saved.password).toBeUndefined();
  });
});
