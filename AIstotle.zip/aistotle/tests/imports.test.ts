import { describe, it, expect, vi, beforeEach } from "vitest";
vi.mock("@/lib/security", async (original) => ({
  ...(await original<typeof import("@/lib/security")>()),
  rateLimit: vi.fn(),
}));
import { POST } from "@/app/api/materials/route";
import { pdfBase64, docxBase64 } from "./fixtures";
function request(
  name: string,
  body: string | ArrayBuffer,
  origin = "http://localhost:3000",
) {
  return new Request(
    `http://localhost:3000/api/materials?name=${encodeURIComponent(name)}`,
    { method: "POST", headers: { origin }, body },
  );
}
beforeEach(() => vi.stubEnv("AUTH_URL", "http://localhost:3000"));
describe("document parsing and upload limits", () => {
  it("extracts plain UTF-8 text", async () => {
    const response = await POST(
      request("notes.txt", "  ATP carries energy.  "),
    );
    expect(response.status).toBe(200);
    expect((await response.json()).text).toBe("ATP carries energy.");
  });
  it("extracts a real PDF in the isolated worker", async () => {
    const bytes = new Uint8Array(Buffer.from(pdfBase64, "base64"));
    const response = await POST(request("notes.pdf", bytes.buffer));
    expect(response.status).toBe(200);
    expect((await response.json()).text).toContain(
      "Photosynthesis makes glucose.",
    );
  }, 20000);
  it("extracts a real DOCX in the isolated worker", async () => {
    const bytes = new Uint8Array(Buffer.from(docxBase64, "base64"));
    const response = await POST(request("notes.docx", bytes.buffer));
    expect(response.status).toBe(200);
    expect((await response.json()).text).toContain(
      "Photosynthesis makes glucose.",
    );
  }, 20000);
  it("rejects a forged PDF and unsupported extensions", async () => {
    expect((await POST(request("fake.pdf", "not a pdf"))).status).toBe(415);
    expect((await POST(request("script.exe", "code"))).status).toBe(415);
  });
  it("rejects empty and binary text", async () => {
    expect((await POST(request("empty.txt", "   "))).status).toBe(422);
    expect((await POST(request("binary.txt", "a\0b"))).status).toBe(400);
  });
  it("rejects an oversized streamed body without trusting content-length", async () =>
    expect(
      (await POST(request("large.txt", "a".repeat(4 * 1024 * 1024 + 1))))
        .status,
    ).toBe(413));
  it("rejects cross-origin uploads", async () =>
    expect(
      (await POST(request("notes.txt", "text", "https://attacker.invalid")))
        .status,
    ).toBe(403));
});
