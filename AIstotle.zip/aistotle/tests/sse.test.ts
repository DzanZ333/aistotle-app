import { describe, it, expect } from "vitest";
import { sseData } from "@/lib/sse";
function stream(parts: string[]) {
  const encoder = new TextEncoder();
  return new ReadableStream<Uint8Array>({
    start(controller) {
      for (const part of parts) controller.enqueue(encoder.encode(part));
      controller.close();
    },
  });
}
describe("SSE parser", () => {
  it("joins arbitrary boundaries, ignores comments, and supports CRLF", async () => {
    const result = [];
    for await (const item of sseData(
      stream([
        ': ping\r\ndata: {"to',
        'ken":"hi"}\r\n\r',
        "\ndata: [DONE]\n\n",
      ]),
    ))
      result.push(item);
    expect(result).toEqual(['{"token":"hi"}', "[DONE]"]);
  });
  it("supports multiline data and final EOF without delimiter", async () => {
    const result = [];
    for await (const item of sseData(stream(["data: first\ndata: second"])))
      result.push(item);
    expect(result).toEqual(["first\nsecond"]);
  });
  it("preserves split multibyte UTF-8", async () => {
    const bytes = new TextEncoder().encode("data: café ☺\n\n");
    const stream = new ReadableStream<Uint8Array>({
      start(c) {
        for (const byte of bytes) c.enqueue(new Uint8Array([byte]));
        c.close();
      },
    });
    const result = [];
    for await (const item of sseData(stream)) result.push(item);
    expect(result).toEqual(["café ☺"]);
  });
});
