import { describe, it, expect } from "vitest";
import {
  reviewCard,
  scoreQuiz,
  scoreAnswer,
  studyStreak,
  createPlan,
} from "@/lib/study";
import {
  workspaceSchema,
  emptyWorkspace,
  questionSchema,
  type Card,
  type Question,
} from "@/lib/schema";
const now = new Date("2026-10-29T12:00:00Z");
const card: Card = {
  id: "1",
  materialId: "m",
  front: "Q",
  back: "A",
  ease: 2.5,
  interval: 0,
  repetitions: 0,
  due: now.toISOString(),
};
const question: Question = {
  id: "q",
  type: "short-answer",
  prompt: "The energy currency of cells?",
  options: [],
  answer: "ATP",
  acceptedAnswers: ["adenosine triphosphate"],
  explanation: "ATP transfers usable energy.",
  topic: "Biology",
};
describe("SM-2 scheduling", () => {
  it("uses one day, then six days, then the previous ease factor", () => {
    const first = reviewCard(card, 4, now);
    expect(first.interval).toBe(1);
    expect(first.repetitions).toBe(1);
    expect(first.ease).toBe(2.5);
    const second = reviewCard(first, 4, now);
    expect(second.interval).toBe(6);
    expect(reviewCard(second, 4, now).interval).toBe(15);
  });
  it("resets repetitions after a failed recall without resetting ease", () => {
    const next = reviewCard({ ...card, repetitions: 8, interval: 100 }, 1, now);
    expect(next.repetitions).toBe(0);
    expect(next.interval).toBe(1);
    expect(next.ease).toBeCloseTo(1.96);
    expect(next.due).toBe("2026-10-30T12:00:00.000Z");
  });
  it("clamps ease to 1.3 and records review time", () => {
    const next = reviewCard({ ...card, ease: 1.3 }, 0, now);
    expect(next.ease).toBe(1.3);
    expect(next.lastReviewed).toBe(now.toISOString());
  });
  it("rewards an effortless recall", () =>
    expect(reviewCard(card, 5, now).ease).toBeCloseTo(2.6));
  it.each([-1, 6, 2.5, NaN])("rejects invalid quality %s", (q) =>
    expect(() => reviewCard(card, q, now)).toThrow(),
  );
  it("does not mutate the original card", () => {
    reviewCard(card, 4, now);
    expect(card.repetitions).toBe(0);
  });
});
describe("quiz scoring", () => {
  it("accepts case, whitespace, punctuation and explicit alternatives", () => {
    expect(scoreAnswer(question, "  atp. ")).toBe(true);
    expect(scoreAnswer(question, "Adenosine   triphosphate")).toBe(true);
  });
  it("rejects empty, incomplete, and merely similar answers", () => {
    expect(scoreAnswer(question, "")).toBe(false);
    expect(scoreAnswer(question, "adenosine")).toBe(false);
    expect(scoreAnswer(question, "ADP")).toBe(false);
  });
  it("preserves meaningful symbols", () => {
    expect(
      scoreAnswer({ ...question, answer: "C++", acceptedAnswers: [] }, "C"),
    ).toBe(false);
  });
  it("scores unanswered questions as incorrect and preserves topics", () =>
    expect(
      scoreQuiz([question, { ...question, id: "q2", topic: "Chemistry" }], {
        q: "ATP",
      }),
    ).toEqual({
      correct: 1,
      total: 2,
      topics: [
        { topic: "Biology", correct: true },
        { topic: "Chemistry", correct: false },
      ],
    }));
  it("validates MCQ answers against four unique options", () =>
    expect(
      questionSchema.safeParse({
        ...question,
        type: "multiple-choice",
        options: ["A", "B", "C", "D"],
        answer: "E",
      }).success,
    ).toBe(false));
  it("rejects malformed true/false questions", () =>
    expect(
      questionSchema.safeParse({
        ...question,
        type: "true-false",
        options: ["Yes", "No"],
        answer: "Yes",
      }).success,
    ).toBe(false));
});
describe("planning and progress", () => {
  it("keeps the daily minute budget and excludes the exam day", () => {
    const tasks = createPlan("2026-11-01", 1, ["Biology", "Accounting"], now);
    expect(tasks).toHaveLength(6);
    for (const day of ["2026-10-29", "2026-10-30", "2026-10-31"])
      expect(
        tasks.filter((t) => t.date === day).reduce((s, t) => s + t.minutes, 0),
      ).toBe(60);
    expect(tasks.some((t) => t.date === "2026-11-01")).toBe(false);
  });
  it("supports a short fifteen-minute daily budget", () =>
    expect(
      createPlan("2026-10-30", 0.25, ["Math"], now).reduce(
        (s, t) => s + t.minutes,
        0,
      ),
    ).toBe(15));
  it("rejects past, invalid, and excessive date ranges", () => {
    for (const day of ["2026-10-29", "2026-02-30", "2028-01-01", "nonsense"])
      expect(() => createPlan(day, 1, ["Math"], now)).toThrow();
  });
  it("does not break a streak before today is studied", () =>
    expect(studyStreak(["2026-10-27", "2026-10-28"], now)).toBe(2));
  it("ignores duplicate activity days and stops at gaps", () =>
    expect(
      studyStreak(
        ["2026-10-25", "2026-10-28", "2026-10-28", "2026-10-29"],
        now,
      ),
    ).toBe(2));
  it("accepts an empty workspace and rejects unexpected content sizes", () => {
    expect(workspaceSchema.safeParse(emptyWorkspace()).success).toBe(true);
    const state = emptyWorkspace();
    state.profile.subject = "x".repeat(101);
    expect(workspaceSchema.safeParse(state).success).toBe(false);
  });
});
