import { describe, it, expect, vi, beforeEach } from "vitest";
const mocked = vi.hoisted(() => ({
  auth: vi.fn(),
  upsert: vi.fn(),
  updateMany: vi.fn(),
  rateLimit: vi.fn(),
}));
vi.mock("@/auth", () => ({ auth: mocked.auth }));
vi.mock("@/lib/db", () => ({
  db: { workspace: { upsert: mocked.upsert, updateMany: mocked.updateMany } },
}));
vi.mock("@/lib/security", async (original) => ({
  ...(await original<typeof import("@/lib/security")>()),
  rateLimit: mocked.rateLimit,
}));
import { GET, PUT } from "@/app/api/workspace/route";
import { emptyWorkspace } from "@/lib/schema";
beforeEach(() => {
  vi.clearAllMocks();
  vi.stubEnv("AUTH_URL", "http://localhost:3000");
  mocked.auth.mockResolvedValue({ user: { id: "owner-1" } });
});
const request = (revision = 2) =>
  new Request("http://localhost:3000/api/workspace", {
    method: "PUT",
    headers: {
      origin: "http://localhost:3000",
      "content-type": "application/json",
    },
    body: JSON.stringify({
      revision,
      data: emptyWorkspace(),
      userId: "attacker-controlled",
    }),
  });
describe("account isolation and optimistic concurrency", () => {
  it("rejects an anonymous workspace read", async () => {
    mocked.auth.mockResolvedValue(null);
    expect((await GET()).status).toBe(401);
    expect(mocked.upsert).not.toHaveBeenCalled();
  });
  it("loads only the authenticated owner", async () => {
    mocked.upsert.mockResolvedValue({
      data: JSON.stringify(emptyWorkspace()),
      revision: 2,
    });
    expect((await GET()).status).toBe(200);
    expect(mocked.upsert.mock.calls[0][0].where).toEqual({ userId: "owner-1" });
  });
  it("ignores caller-supplied ownership and increments the revision atomically", async () => {
    mocked.updateMany.mockResolvedValue({ count: 1 });
    const result = await PUT(request());
    expect(result.status).toBe(200);
    expect(await result.json()).toEqual({ revision: 3 });
    expect(mocked.updateMany.mock.calls[0][0].where).toEqual({
      userId: "owner-1",
      revision: 2,
    });
  });
  it("returns a conflict rather than overwriting newer state", async () => {
    mocked.updateMany.mockResolvedValue({ count: 0 });
    expect((await PUT(request())).status).toBe(409);
  });
});
