import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";
export default defineConfig({
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  test: {
    server: { deps: { inline: ["next-auth"] } },
    environment: "node",
    include: ["tests/**/*.test.ts"],
  },
});
